# 第 9 期素材出处（只在本机，不进 git）

| 用在 | 素材 | 出处 | 作者 / 版权 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| op12q 原声 | Joe Rogan Experience #2422（1:49:13–1:49:32 片段） | https://www.youtube.com/watch?v=3hptKYix4X8 | PowerfulJRE（Joe Rogan） | 版权所有，新闻评论引用片段，主讲 2026-11-13 同意下载 | 2026-11-13 |
| kid17q 原声 | Jensen Huang, Founder and CEO of NVIDIA（Stanford GSB View From The Top，30:34–30:45） | https://www.youtube.com/watch?v=lXLBTBBil2U | Stanford Graduate School of Business | 同上 | 2026-11-13 |
| gun15q 原声 | 顯卡教父黃仁勳台大畢典致詞【致詞全程】（12:38–12:54；画面裁掉台标和横幅） | https://www.youtube.com/watch?v=_sftvrqIfIU | 台視新聞 TTV NEWS | 同上 | 2026-11-13 |
| cuda13q 原声 | Keynote by NVIDIA CEO Jensen Huang at 2024 SIEPR Economic Summit（38:10–38:28） | https://www.youtube.com/watch?v=cEg8cOx7UZk | Stanford Institute for Economic Policy Research | 同上 | 2026-11-13 |
| boom22q 原声 | The Rise and Reckoning of Jensen Huang, The Circuit with Emily Chang（36:17–36:30，柏林） | https://www.youtube.com/watch?v=JW5s9Md4U2U | Bloomberg Originals | 同上 | 2026-11-13 |
| 照片 jensen_ces2025.jpg | Jensen Huang Nvidia Keynote CES 2025.jpg | https://commons.wikimedia.org/wiki/File:Jensen_Huang_Nvidia_Keynote_CES_2025.jpg | Joseph Zadeh | CC BY-SA 4.0 | 2026-11-13 |
| 照片 jensen_stanford2026.jpg | Jensen huang stanford 2026-04-30 024.jpg | https://commons.wikimedia.org/wiki/File:Jensen_huang_stanford_2026-04-30_024.jpg | Anderseidesvik | CC BY-SA 4.0 | 2026-11-13 |
| 照片 nvidia_sign.jpg | Nvidia sign.jpg | https://commons.wikimedia.org/wiki/File:Nvidia_sign.jpg | Will Buckner | CC BY 2.0 | 2026-11-13 |
| op1–op3 文件原页 | NVIDIA Announces CEO Transition（网页截图，960 宽，2 倍） | https://nvidianews.nvidia.com/news/nvidia-announces-ceo-transition | NVIDIA | 新闻稿截图，评论引用 | 2026-11-13 |
| op4–op5 文件原页 | A Message to Our Company（网页截图，只截到第二段） | https://nvidianews.nvidia.com/news/a-message-to-our-company | NVIDIA / Jensen Huang | 公开信截图，评论引用 | 2026-11-13 |
| 开场配乐 | susp_lnplus（lnplusmusic · Suspense Tension） | https://cdn.pixabay.com/download/audio/2025/04/05/audio_c3cb571f3b.mp3 | lnplusmusic | Pixabay Content License（主讲第 8 期手动下载） | 2026-10-29 |
| 开场配乐 | epic_starostin（Starostin · Documentary） | https://cdn.pixabay.com/download/audio/2026/10/26/audio_a7f762383b.mp3 | Starostin | Pixabay Content License（主讲第 8 期手动下载） | 2026-10-29 |
| 片名卡音效 | sfx_soft_impact | 工具包 assets/manifest.json 登记的音效 | 见 manifest | 见 manifest | 2026-10-29 |
| op1–op3 桌面远处（虚化） | Statement From NVIDIA Board of Directors（2026-11-08）网页截图 | https://nvidianews.nvidia.com/news/statement-from-nvidia-board-of-directors | NVIDIA | 新闻稿截图，评论引用 | 2026-11-13 |
| op1–op3 桌面远处（虚化） | Statement From the Independent Members of the NVIDIA Board（2026-11-10）网页截图 | https://nvidianews.nvidia.com/news/statement-from-the-independent-members-of-the-nvidia-board | NVIDIA | 新闻稿截图，评论引用 | 2026-11-13 |
| 注 | CES 照片压暗、虚化后作底，属改编，片中署名「Joseph Zadeh · CC BY-SA 4.0」，简介里也写一行 | | | | |
| 翻牌咔嗒声 | sfx_tick | 工具包 assets/manifest.json 登记的音效（第 8 期素材库） | 见 manifest | 见 manifest | 2026-10-29 |
| gun12q 原声 | 顯卡教父黃仁勳台大畢典致詞（11:52–12:03，「Either way, we would be out of business」；画面裁掉台标） | https://www.youtube.com/watch?v=_sftvrqIfIU | 台視新聞 TTV NEWS | 版权所有，评论引用片段，主讲 2026-11-13 同意下载 | 2026-11-13 |
| gun21q 原声 | NVIDIA CEO Jensen Huang（Acquired，9:08–9:31） | https://www.youtube.com/watch?v=y6NfxiemvHg | Acquired（Ben Gilbert、David Rosenthal） | 同上 | 2026-11-13 |
| cuda 备用原声 | A conversation with NVIDIA's Jensen Huang（Stripe Sessions 2024，28:47–29:01） | https://www.youtube.com/watch?v=8Pfa8kPjUio | Stripe | 同上 | 2026-11-13 |
| 「倒闭」低音钢琴单音 | sfx_lowpiano.wav（从 epic_leberch_piano 18.15–21.35 秒切出的单个低音 G#） | https://cdn.pixabay.com/download/audio/2026/10/02/audio_be1c8cd699.mp3 | Leberch | Pixabay Content License（主讲第 8 期手动下载） | 2026-11-13 |
| 开场配乐 | 《Claude Opus 小曲》 opus_xiaoqu_wenever.m4a（第 8 期第 1 集配乐版用过；主讲 2026-11-14 指定） | 主讲提供 | Wenever | 未获授权（主讲知情，只用于抖音/B站，不进公开仓库） | 2026-11-14 |
| op7–op9 交易屏实拍 | Financial Market（Pexels 7579577，4096×2160，取前 12 秒） | https://www.pexels.com/video/financial-market-7579577/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 开头快剪 1 | Foggy Mountain（Pexels 855615） | https://www.pexels.com/video/foggy-mountain-855615/ | 见作品页 | Pexels License | 2026-11-14 |
| 开头快剪 3 | People Playing Table Tennis（Pexels 5592050） | https://www.pexels.com/video/people-playing-table-tennis-5592050/ | Artyom Hunter | Pexels License | 2026-11-14 |
| 开头快剪 4–5 | Customers Going In and Out of Restaurant（Pexels 6589392） | https://www.pexels.com/video/customers-going-in-and-out-of-restaurant-6589392/ | 见作品页 | Pexels License | 2026-11-14 |
| 开头快剪 2 | A Person Mopping Clean A Comfort Room（Pexels 2517780） | https://www.pexels.com/video/a-person-mopping-clean-a-comfort-room-2517780/ | 见作品页 | Pexels License | 2026-11-14 |

## v8 新增（2026-11-14 补）

| 用在 | 素材 | 出处 | 作者 / 版权 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| v8 上升段照片 C1_1.jpg（备选，剪辑表未用） | Graphics Card Diamond Viper 330 with Nvidia (RIVA 128) GPU.jpg | https://commons.wikimedia.org/wiki/File:Graphics_Card_Diamond_Viper_330_with_Nvidia_(RIVA_128)_GPU.jpg | Timothy Borkowski | CC BY-SA 3.0 | 2026-11-14 |
| v8 上升段照片 C1_2.jpg（E7 k12 RIVA 128（碑）） | Elsa Victory Erazor-AGP-4 - Nvidia RIVA 128-7094.jpg | https://commons.wikimedia.org/wiki/File:Elsa_Victory_Erazor-AGP-4_-_Nvidia_RIVA_128-7094.jpg | Raimond Spekking | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C2_1.jpg（开场没用；正片「只有一枪」用了：英伟达的第一款芯片那一镜） | Diamond Edge 3D 3400.jpg | https://commons.wikimedia.org/wiki/File:Diamond_Edge_3D_3400.jpg | Hyins at Chinese Wikipedia | Public domain | 2026-11-14 |
| v8 上升段照片 C2_2.jpg（E5 k8 NV1（碑）） | NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X B A22FN9609 MALTA DSC05885 (27662108651).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X_B_A22FN9609_MALTA_DSC05885_(27662108651).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-14 |
| v8 上升段照片 C2_3.jpg（备选，剪辑表未用） | Dedge3d.jpg | https://commons.wikimedia.org/wiki/File:Dedge3d.jpg | Swaaye at English Wikipedia | CC BY-SA 3.0 | 2026-11-14 |
| v8 上升段照片 C3_1.jpg（备选，剪辑表未用） | KL NVIDIA Geforce 256.jpg | https://commons.wikimedia.org/wiki/File:KL_NVIDIA_Geforce_256.jpg | Konstantin Lanzet | CC BY-SA 3.0 | 2026-11-14 |
| v8 上升段照片 C3_2.jpg（备选，剪辑表未用） | VisionTek GeForce 256.jpg | https://commons.wikimedia.org/wiki/File:VisionTek_GeForce_256.jpg | Hyins | Public domain | 2026-11-14 |
| v8 上升段照片 C3_3.jpg（E8 k14 GeForce 256（小碑）） | NVIDIA@220nm@Fixed-pipline@NV10@GeForce 256@T5A3202220008 S1 Taiwan A DSC01375 (29587991824).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@220nm@Fixed-pipline@NV10@GeForce_256@T5A3202220008_S1_Taiwan_A_DSC01375_(29587991824).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-14 |
| v8 上升段照片 C4_1.jpg（备选，剪辑表未用） | NVIDIA GeForce 8800 Ultra Board.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_GeForce_8800_Ultra_Board.jpg | Hyins | Public domain | 2026-11-14 |
| v8 上升段照片 C4_2.jpg（备选，剪辑表未用） | PNY XLR8 8800GTS 640MB.jpg | https://commons.wikimedia.org/wiki/File:PNY_XLR8_8800GTS_640MB.jpg | TheStriker | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C4_3.jpg（备选，剪辑表未用） | 3-way-SLI.jpg | https://commons.wikimedia.org/wiki/File:3-way-SLI.jpg | User:Coaster J | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C5_1.jpg（备选，剪辑表未用） | EVGAGeforceGTX580.jpg | https://commons.wikimedia.org/wiki/File:EVGAGeforceGTX580.jpg | TheStriker | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C5_2.jpg（E10b k18 GTX 580 的芯片，立在 AlexNet 论文页旁边） | NVIDIA@40nm@Fermi@GF110@GeForce GTX 580@UA10B338 1041A1 N2Y540.000 GF110-375-A1 DSC06727 (28114557571).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@40nm@Fermi@GF110@GeForce_GTX_580@UA10B338_1041A1_N2Y540.000_GF110-375-A1_DSC06727_(28114557571).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-14 |
| v8 上升段照片 C6_1.jpg（E6 k10 世嘉 Saturn） | Sega-Saturn-JP-Mk2-Console-Set.jpg | https://commons.wikimedia.org/wiki/File:Sega-Saturn-JP-Mk2-Console-Set.jpg | Evan-Amos | Public domain | 2026-11-14 |
| v8 上升段照片 C6_2.jpg（备选，剪辑表未用） | Sega-Dreamcast-Console-FL.jpg | https://commons.wikimedia.org/wiki/File:Sega-Dreamcast-Console-FL.jpg | Evan-Amos | Public domain | 2026-11-14 |
| v8 上升段照片 C6_3.jpg（备选，剪辑表未用） | Virtua Fighter 2 2026-08-14.jpg | https://commons.wikimedia.org/wiki/File:Virtua_Fighter_2_2026-08-14.jpg | GuiltyGearFan37 | CC0 | 2026-11-14 |
| v8 上升段照片 C7_1.jpg（E4 k6 Berryessa 路那家 Denny’s） | 2484 Berryessa Road.jpg | https://commons.wikimedia.org/wiki/File:2484_Berryessa_Road.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C7_2.jpg（E3 k4 Denny’s） | Denny's 7064.jpg | https://commons.wikimedia.org/wiki/File:Denny%27s_7064.jpg | Chris Light | CC BY-SA 4.0 | 2026-11-14 |
| v8 上升段照片 C7_3.jpg（备选，剪辑表未用） | Denny's Restaurant (Sherman Way).jpg | https://commons.wikimedia.org/wiki/File:Denny%27s_Restaurant_(Sherman_Way).jpg | Alexis Doine | CC0 | 2026-11-14 |
| v8 上升段照片 C8_1.jpg（备选，剪辑表未用） | Calf igloos at OBI, Kentucky, USA.jpg | https://commons.wikimedia.org/wiki/File:Calf_igloos_at_OBI,_Kentucky,_USA.jpg | James Thompson | CC BY 2.0 | 2026-11-14 |
| v8 上升段照片 C8_2.jpg（E1 k0 1973 Oneida） | River Street in Oneida.jpg | https://commons.wikimedia.org/wiki/File:River_Street_in_Oneida.jpg | Nyttend | Public domain | 2026-11-14 |
| v8 上升段照片 TT_1.jpg（E2 k2 乒乓球） | Table tennis bat and ball.jpg | https://commons.wikimedia.org/wiki/File:Table_tennis_bat_and_ball.jpg | Santeri Viinamäki | CC BY-SA 4.0 | 2026-11-14 |
| v8 音效 sfx_v8/light_fluo_onoff.mp3 | Fluorescent lamp in bathroom on-off.wav | https://freesound.org/people/Daphne_in_Wonderland/sounds/383487 | Daphne_in_Wonderland | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/light_fluo_onoff2.mp3 | Turn On/Off a Fluorescent Lamp | https://freesound.org/people/leonelmail/sounds/320874 | leonelmail | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/breaker_1.mp3 | Breaker Switch | https://freesound.org/people/ZapertyHD/sounds/465696 | ZapertyHD | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/breaker_2.mp3 | Circuit Breaker 2 DP.wav | https://freesound.org/people/sribubba/sounds/130153 | sribubba | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/breaker_3.mp3 | Circuit Breaker 3 DP.wav | https://freesound.org/people/sribubba/sounds/130154 | sribubba | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/breaker_big_onoff.mp3 | switch big breaker metal click on, off.flac | https://freesound.org/people/kyles/sounds/451933 | kyles | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/switch_big_power.mp3 | Switch.Big.Power.wav | https://freesound.org/people/jessepash/sounds/139970 | jessepash | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/relay_click.mp3 | A relay switch being activated. | https://freesound.org/people/bassmosphere/sounds/384698 | bassmosphere | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/light_switch_off.mp3 | Light Switch Off | https://freesound.org/people/vmgraw/sounds/235612 | vmgraw | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/crowd_arena.mp3 | crowd large cheer arena stadium hockey game Montreal Canadiens Habs chant applause whistle.flac | https://freesound.org/people/kyles/sounds/629884 | kyles | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/crowd_goal.mp3 | 19 Football Crowd - Reaction To Goal.flac | https://freesound.org/people/D.jones/sounds/528799 | D.jones | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/page_turn.mp3 | Page Turn | https://freesound.org/people/davidbain/sounds/136778 | davidbain | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/page_turn_fast.mp3 | Page Turn 02.wav | https://freesound.org/people/MATRIXXX_/sounds/397549 | MATRIXXX_ | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/underline_stroke.mp3 | Underlining Stroke on Paper | https://freesound.org/people/zembacraftworks/sounds/428338 | zembacraftworks | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/marker_strokes.mp3 | fast and slow marker strokes | https://freesound.org/people/MBPiM/sounds/351145 | MBPiM | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/room_tone_office.mp3 | Room Tone Office Quiet Distant Traffic.wav | https://freesound.org/people/mzui/sounds/135097 | mzui | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/wood_thud.mp3 | Wood Thud Underfoot.wav | https://freesound.org/people/spookymodem/sounds/202106 | spookymodem | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/kick_low.mp3 | Tamburo XD 18 kick - low jazz 3 single.wav | https://freesound.org/people/bigjoedrummer/sounds/77302 | bigjoedrummer | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/type_key1.mp3 | Typewriter - single key - type 1.wav | https://freesound.org/people/yottasounds/sounds/380138 | yottasounds | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/type_key2.mp3 | Typewriter - single key - type 2.wav | https://freesound.org/people/yottasounds/sounds/380137 | yottasounds | CC0 1.0（Freesound） | 2026-11-14 |
| v8 音效 sfx_v8/shutter_burst.mp3 | Leica_M11_Shutter_burst_dry_sound_96kHz_32bit-float | https://freesound.org/people/TSP-Talk/sounds/720702 | TSP-Talk | CC0 1.0（Freesound） | 2026-11-14 |
| v8 山顶巨墙 gtc25_entrance.mp4（只用画面） | NVIDIA GTC 2025 主旨演讲（203–228 秒） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | NVIDIA | 版权所有，评论引用片段，主讲 2026-11-13 同意 | 2026-11-14 |
| v8 备用 gtc25_5090.mp4 | NVIDIA GTC 2025 主旨演讲（314–324 秒） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | NVIDIA | 同上 | 2026-11-14 |
| v8 备用 gtc25_closing.mp4 | NVIDIA GTC 2025 主旨演讲（7874–7896 秒） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | NVIDIA | 同上 | 2026-11-14 |
| v8 E11 k19 DGX-1 nv_dgx1_2016.mp4 | 10 Years of NVIDIA DGX（27–57 秒） | https://www.youtube.com/watch?v=xAgq8ByWK0M | NVIDIA | 版权所有，评论引用片段，主讲 2026-11-14 同意 | 2026-11-14 |
| v8 E9 k16 各代显卡 nv_gpu_history.mp4 | NVIDIA GPUs: 1999 to Now（全片 24 秒） | https://www.youtube.com/watch?v=I25dLTIPREA | NVIDIA | 同上 | 2026-11-14 |
| v8 原声 kill（acquired_killyou.mp4 14.88–16.735 秒：“if you lose my money, I’ll kill you”） | Acquired 播客 NVIDIA 访谈（4254–4276 秒） | https://www.youtube.com/watch?v=y6NfxiemvHg | Acquired（Ben Gilbert、David Rosenthal） | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/nv_letter.png / nv_letter_n.png（k32–33.5 他的信） | A Message to Our Company（2026-11-08，网页截图 960 宽 ×4） | https://nvidianews.nvidia.com/news/a-message-to-our-company | NVIDIA / Jensen Huang | 公开信截图，评论引用；avoid 句不入画 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/nv_stmt_board.png / nv_stmt_board_n.png（k34 董事会声明） | Statement From NVIDIA Board of Directors（2026-11-08，网页截图） | https://nvidianews.nvidia.com/news/statement-from-nvidia-board-of-directors | NVIDIA | 新闻稿截图，评论引用；avoid 句不入画 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/nv_ceo.png / nv_ceo_n.png（k38–42 辞职公告） | NVIDIA Announces CEO Transition（2026-11-12，网页截图） | https://nvidianews.nvidia.com/news/nvidia-announces-ceo-transition | NVIDIA | 新闻稿截图，评论引用 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/ipo_424b4_cover.png（E8 k14 招股书封面） | NVIDIA 424B4 招股书（1999-01-21，EDGAR 0001012870-99-000192）原文本按等宽字体排版，文字未改；不是 sec.gov 截图 | https://web.archive.org/web/20170226182051id_/https://www.sec.gov/Archives/edgar/data/1045810/0001012870-99-000192.txt（Internet Archive 存档；原址 https://www.sec.gov/Archives/edgar/data/1045810/0001012870-99-000192.txt） | NVIDIA（美国 SEC 公开文件） | 公开文件，评论引用 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/alexnet_p2.png（及 alexnet_p1.png）（E10 k18 AlexNet 论文第 2 页） | ImageNet Classification with Deep Convolutional Neural Networks（NIPS 2012），由本地 assets/docs/alexnet_2012.pdf 按 400 dpi 渲染 | https://papers.nips.cc/paper_files/paper/2012/file/c399862d3b9d6b76c8436e924a68c45b-Paper.pdf | Krizhevsky、Sutskever、Hinton | 论文页面，评论引用 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_01.png（k36.5 标题） | CNBC：Nvidia board meeting to decide CEO Jensen Huang’s fate stretches into evening（2026-11-11） | https://www.cnbc.com/2026/11/11/nvidia-jensen-huang-affair-employee.html | CNBC | 标题截图，评论引用 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_02.png（k44 标题） | CNBC：Nvidia stock closes down over 4% after CEO Jensen Huang announces resignation（2026-11-12） | https://www.cnbc.com/2026/11/12/nvidia-nvda-jensen-huang-second-affair.html | CNBC | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_03.png（k46.5 标题叠） | CNBC：‘A dark day for Nvidia’: Here’s what analysts have been saying about Jensen Huang’s departure（2026-11-12） | https://www.cnbc.com/2026/11/12/jensen-huang-nvidia-affair-ceo.html | CNBC | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_04.png（备用（剪辑表未用）） | CNBC：Nvidia closes below $4T market cap for first time since July 2025 in Huang fallout（2026-11-13） | https://www.cnbc.com/2026/11/13/nvidia-nvda-stock-jensen-huang-transition.html | CNBC | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_05.png（k47.5 标题叠） | CNBC：Nvidia hasn’t selected search firm for permanent Huang replacement, board tells CNBC（2026-11-13） | https://www.cnbc.com/2026/11/13/nvidia-huang-ceo-replacement-search.html | CNBC | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/headline_06.png（开场没用；正片「四天」用了：1.08 亿美元那一镜） | Bloomberg Law：Jensen Huang Forfeits $108 Million in Unvested Nvidia Equity (2)（2026-11-12） | https://news.bloomberglaw.com/capital-markets/jensen-huang-walks-away-from-108-million-in-unvested-equity | Bloomberg Law | 同上 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/tweet_2016.png（备用（剪辑表未用）） | X 帖子（2016-08-09，官方嵌入组件渲染） | https://x.com/elonmusk/status/763096729134575617 | Elon Musk | 帖子截图，评论引用 | 2026-11-14 |
| v8 文件原页 assets/docs/v8/tweet_dgx1.png（备用（剪辑表未用）） | X 帖子（2024-02-18，官方嵌入组件渲染） | https://x.com/elonmusk/status/1759295781196927438 | Elon Musk | 同上 | 2026-11-14 |
| v8 山顶巨墙 W2 和原声 pass（circuit_pass.mp4 4.27–5.43 秒：“All of this is going to pass”） | The Rise and Reckoning of Jensen Huang, The Circuit with Emily Chang（36:17–36:30，柏林） | https://www.youtube.com/watch?v=JW5s9Md4U2U | Bloomberg Originals | 版权所有，评论引用片段，主讲 2026-11-13 同意下载 | 2026-11-13 |
| v8 开头原声和第一块屏 E0（gsb_toilets.mp4） | Jensen Huang, Founder and CEO of NVIDIA（Stanford GSB View From The Top，30:34–30:45） | https://www.youtube.com/watch?v=lXLBTBBil2U | Stanford Graduate School of Business | 同上 | 2026-11-13 |
| v8 原声 oob（ntu_outofbusiness.mp4，只用声音：“Either way, we would be out of business”） | 顯卡教父黃仁勳台大畢典致詞（11:52–12:03） | https://www.youtube.com/watch?v=_sftvrqIfIU | 台視新聞 TTV NEWS | 同上 | 2026-11-13 |
| v8 结尾 Rogan 画面和原声（rogan_30days.mp4） | Joe Rogan Experience #2422（1:49:13–1:49:32 片段） | https://www.youtube.com/watch?v=3hptKYix4X8 | PowerfulJRE（Joe Rogan） | 同上 | 2026-11-13 |
| v8 Blender 贴图与文件对应 | film/work_v8/blender/tex/manifest.json（每块展品用的源文件、裁切和调色） | 本机 | — | — | 2026-11-14 |
| v8 配乐 | 《Claude Opus 小曲》（见上表「开场配乐」那一行：未获授权，主讲知情，不进公开仓库） | 主讲提供 | Wenever | 未获授权 | 2026-11-14 |

## 正片新增（2026-11-14 晚，主讲同意「自己去下就行」）

| 用在 | 素材 | 出处 | 作者 / 版权 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| 正片文件页 assets/docs/v8/cnbc_1110_anthropic.png | Anthropic sets price range of $70 to $78 in upcoming IPO（只截这一句：planning to price on Nov. 18 and trade on Nov. 19） | https://www.cnbc.com/2026/11/10/anthropic-sets-price-range-of-70-to-78-in-upcoming-ipo.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1111_postmarket.png | Nvidia board meets to decide CEO Jensen Huang’s fate（只截这一句：Shares of Nvidia fell more than 9% in post-market trading） | https://www.cnbc.com/2026/11/11/nvidia-jensen-huang-affair-employee.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1112_ives.png | Jensen Huang: Analysts weigh in on Nvidia's future（只截这一句：We believe Nvidia’s value is $300 per share with Jensen as CEO and $22） | https://www.cnbc.com/2026/11/12/jensen-huang-nvidia-affair-ceo.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1112_live_oust.png | Nvidia CEO Jensen Huang resigns: Live updates（只截这一句：Nvidia’s board decided last night to oust longtime CEO Jensen Huang） | https://www.cnbc.com/2026/11/12/nvidia-jensen-huang-ceo-live-updates.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1112_live_retail.png | Nvidia CEO Jensen Huang resigns: Live updates（只截这一句：retail traders bought a net $111 million of Nvidia shares, more than 4） | https://www.cnbc.com/2026/11/12/nvidia-jensen-huang-ceo-live-updates.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1112_thooft.png | Jensen Huang: Analysts weigh in on Nvidia's future（只截这一句：there is still 40,000 other employees at Nvidia） | https://www.cnbc.com/2026/11/12/jensen-huang-nvidia-affair-ceo.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1113_financing.png | What's ahead for AI financing after Nvidia CEO Jensen Huang departs（只截这一句：Jensen was so crucial in selling the Nvidia story and being a very agg） | https://www.cnbc.com/2026/11/13/nvidia-jensen-huang-resignation-ai-financing.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_1113_week.png | Nvidia closes below $4T market cap for first time since July 2025 in Huang fallo（只截这一句：The stock declined 12.75% in the trading week） | https://www.cnbc.com/2026/11/13/nvidia-nvda-stock-jensen-huang-transition.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_live_anthropic10b.png | Nvidia CEO Jensen Huang resigns: Live updates（只截这一句：agreed to purchase another $10 billion worth of its Class N common sto） | https://www.cnbc.com/2026/11/12/nvidia-jensen-huang-ceo-live-updates.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_live_stake.png | Nvidia CEO Jensen Huang resigns: Live updates（只截这一句：Jensen Huang’s $140 billion Nvidia stake） | https://www.cnbc.com/2026/11/12/nvidia-jensen-huang-ceo-live-updates.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/cnbc_market_week.png | Stock market news for Nov. 13, 2026（只截这一句：The Nasdaq added 2.3%, while the S&P 500 rose 2.5%） | https://www.cnbc.com/2026/11/12/stock-market-today-live-updates.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/fool_broadcom_xpu.png | Broadcom (AVGO) Q3 2026 Earnings Call Transcript | The Motley Fool（只截这一句：Anthropic is on track to become our largest XPU customer in 2027） | https://www.fool.com/earnings/call-transcripts/2026/09/09/broadcom-avgo-q3-2026-earnings-call-transcript/ | 见网址 | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/fortune_1109_16pct.png | Nvidia CEO Jensen Huang is likely to hold on to his job, say prediction markets （只截这一句：Traders put the probability of an announcement by year-end at 16%） | https://fortune.com/2026/11/09/jensen-huangs-affair-prediction-market-bets-nvidia-ceo/ | Fortune | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/gizmodo_circular.png | Nvidia Tries to Defend Against Circular Dealmaking Accusations（只截这一句：we know some will call this circular financing. We see it differently） | https://gizmodo.com/nvidia-tries-to-defend-against-circular-dealmaking-accusations-2000803583 | Gizmodo | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nbc_1113_investigating.png | Nvidia’s board is still investigating Jensen Huang despite his resignation, sour（只截这一句：plan to continue investigating former CEO Jensen Huang） | https://www.nbcnews.com/tech/tech-news/nvidia-investigation-jensen-huang-continue-departure-sources-say-rcna609136 | NBC News | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nbcbay_dennys_h1.png | Trillion-dollar tech company gets its start at a South Bay Denny’s booth – NBC B（只截这一句：Trillion-dollar tech company gets its start at a South Bay Denny's boo） | https://www.nbcbayarea.com/news/local/south-bay/nvidia-ceo-dennys-san-jose/3327542/ | NBC Bay Area | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nbcbay_dennys_hang.png | Trillion-dollar tech company gets its start at a South Bay Denny’s booth – NBC B（只截这一句：We would hang out here for hours and talk about what NVIDIA would be） | https://www.nbcbayarea.com/news/local/south-bay/nvidia-ceo-dennys-san-jose/3327542/ | NBC Bay Area | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/npr_2012_oneida.png | Nvidia CEO Jen-Hsun Huang: Tech Pioneer Channels Hard Lessons Into Silicon Valle（只截这一句：they could apply to Oneida / every kid had to work / They all had pocket knives / The ending of the story is I loved the time I was there） | https://www.npr.org/sections/alltechconsidered/2012/02/20/147162496/tech-pioneer-channels-hard-lessons-into-silicon-valley-success | NPR | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nv_cfo_q2fy27_commit.png | Document（只截这一句：Our commitments increased from $119 billion last quarter to $279 billi） | https://web.archive.org/web/20260827114621/https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/q2fy27cfocommentary.htm | NVIDIA（SEC 8-K 附件，Internet Archive 副本） | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nv_proxy_2026_own.png | nvda-20260512（只截这一句：870,604,104） | https://web.archive.org/web/20261111131320id_/https://www.sec.gov/Archives/edgar/data/1045810/000104581026000036/nvda-20260512.htm | NVIDIA（SEC DEF 14A，Internet Archive 副本） | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nv_proxy_2026_vote.png | nvda-20260512（只截这一句：one vote for each share of NVIDIA common stock） | https://web.archive.org/web/20261111131320id_/https://www.sec.gov/Archives/edgar/data/1045810/000104581026000036/nvda-20260512.htm | NVIDIA（SEC DEF 14A，Internet Archive 副本） | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nv_q2fy27_pr.png | NVIDIA Announces Financial Results for Second Quarter Fiscal 2027 | NVIDIA Newsr（只截这一句：Revenue of $96.2 billion） | https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-second-quarter-fiscal-2027 | NVIDIA | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/nvblog_dennys_plaque.png | Jensen Huang Returns to Denny’s Where NVIDIA Launched a Trillion-Dollar Vision |（只截这一句：Huang and Denny’s CEO unveil plaque at the diner where NVIDIA’s founde） | https://blogs.nvidia.com/blog/nvidia-dennys-trillion/ | NVIDIA | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/standard_openai_30b.png | Nvidia CEO hints at end of investments in OpenAI, Anthropic（只截这一句：Nvidia has instead finalized a US$30 billion investment in OpenAI） | https://www.thestandard.com.hk/innovation/article/325932/Nvidia-CEO-hints-at-end-of-investments-in-OpenAI-Anthropic | The Standard（转载路透） | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/vgc_sega_5m.png | Nvidia’s Jensen Huang reunites with Sega exec who saved the company with $5M inv（只截这一句：saved the company with $5M investment） | https://www.videogameschronicle.com/news/nvidias-jensen-huang-reunites-with-sega-exec-who-saved-the-company-with-5m-investment/ | VGC | 网页截图，评论引用 | 2026-11-14 |
| 正片视频 assets/src_clips/oracle_dinner.mp4 | Oracle Financial Analyst Meeting 2024 · Q&A with Larry Ellison（21:36–22:28） | https://www.youtube.com/watch?v=O501x3Ei10Y | Oracle | 版权所有，评论引用片段 | 2026-11-14 |
| 正片视频 assets/src_clips/dwarkesh_nobeg.mp4 | Dwarkesh Podcast 片段（1:52–2:30，黄仁勋谈那顿饭） | https://www.youtube.com/watch?v=nzGjvZrWKF8 | Dwarkesh Patel | 版权所有，评论引用片段 | 2026-11-14 |
| 正片视频 assets/src_clips/rogan_insecurity.mp4 | Joe Rogan Experience #2422（1:49:24–1:49:48） | https://www.youtube.com/watch?v=3hptKYix4X8 | PowerfulJRE（Joe Rogan） | 版权所有，评论引用片段 | 2026-11-14 |
| 正片视频 assets/src_clips/rogan_oneida.mp4 | Joe Rogan Experience #2422（2:08:08–2:10:46） | https://www.youtube.com/watch?v=3hptKYix4X8 | PowerfulJRE（Joe Rogan） | 版权所有，评论引用片段 | 2026-11-14 |
| 正片视频 assets/src_clips/gtc25_morebuy.mp4 | NVIDIA GTC 2025 主旨演讲（1:21:04–1:21:26） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | NVIDIA | 版权所有，评论引用片段 | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_40806780_office_night.mp4（可用：夜里亮灯的办公楼） | Modern Office Building at Night（Pexels 40806780） | https://www.pexels.com/video/modern-office-building-at-night-40806780/ | 정규송 Nui MALAMA | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_8064155_buildings_lights.mp4（备选（住宅楼群，不太合）） | Video Of Buildings With Lights Opening（Pexels 8064155） | https://www.pexels.com/video/video-of-buildings-with-lights-opening-8064155/ | Antoni Shkraba | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_6951393_conference_room.mp4（可用：空会议室（白天，用时压暗）） | An Empty Conference Room（Pexels 6951393） | https://www.pexels.com/video/an-empty-conference-room-6951393/ | Werner Pfennig | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_38725029_stock_screen_dark.mp4（不用：屏上是加密货币行情） | Stock Market Screen Display in Dim Room（Pexels 38725029） | https://www.pexels.com/video/stock-market-screen-display-in-dim-room-38725029/ | Rafael Minguet Delgado | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_29188237_us_capitol.mp4（可用：国会大厦（那一句留不留等主讲定）） | Iconic View of the US Capitol Building（Pexels 29188237） | https://www.pexels.com/video/iconic-view-of-the-us-capitol-building-29188237/ | In Old News LLC | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_7140928_server_leds.mp4（可用：服务器指示灯特写） | Close Up of a CPU（Pexels 7140928） | https://www.pexels.com/video/close-up-of-a-cpu-7140928/ | MrColo | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_5028622_server_room.mp4（备选（机房偏亮偏乱）） | Database Storage of a Server（Pexels 5028622） | https://www.pexels.com/video/database-storage-of-a-server-5028622/ | ALL IZ Well | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_37208833_warehouse_aisle.mp4（不用：货架上是布料麻袋） | Industrial Warehouse Storage Aisle With Packed Shelves（Pexels 37208833） | https://www.pexels.com/video/industrial-warehouse-storage-aisle-with-packed-shelves-37208833/ | Mahadi Hassan Molla | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_35907902_port_dusk.mp4（可用：黄昏的集装箱码头） | Aerial View of Busy Shipping Port at Dusk（Pexels 35907902） | https://www.pexels.com/video/aerial-view-of-busy-shipping-port-at-dusk-35907902/ | willy one | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_6755158_chip_closeup.mp4（可用：芯片特写） | Close-up Shot of Electronic Chip（Pexels 6755158） | https://www.pexels.com/video/close-up-shot-of-electronic-chip-6755158/ | Tima Miroshnichenko | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_6754818_motherboard.mp4（可用：电路板上的存储芯片特写） | Close-up View of a Motherboard（Pexels 6754818） | https://www.pexels.com/video/close-up-view-of-a-motherboard-6754818/ | Tima Miroshnichenko | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_4319342_nyse_exterior.mp4（可用：纽交所外立面） | Finance NYSE Wall Street New York City（Pexels 4319342） | https://www.pexels.com/video/finance-nyse-wall-street-new-york-city-4319342/ | CityXcape | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_36135749_rotary_phone.mp4（不用：复古红电话，和 2026 年对不上） | Rotary Dial Phone With Hand Dialing Indoors（Pexels 36135749） | https://www.pexels.com/video/rotary-dial-phone-with-hand-dialing-indoors-36135749/ | Yeşim Çolak | Pexels License（免费使用，不要求署名） | 2026-11-14 |

## 正片各章从已登记源片里抽的帧序列（2026-11-14 夜）

源片的来源和授权见上面各行，这里只记哪一章用了哪一段。

| 帧序列（assets/clips/） | 源片 | 起点 | 长度 | 用在 |
|---|---|---|---|---|
| out_gtc_exit | assets/src_clips/gtc25_closing.mp4（NVIDIA GTC 2025 主旨演讲） | 17.0 秒 | 2.6 秒（片中用 1.2 秒，慢放） | 四天 |
| out_mkt_a | assets/src_clips/pexels_7579577_financial_market.mp4 | 12.0 秒 | 4.6 秒 | 四天 |
| out_mkt_b | 同上 | 16.6 秒 | 4.6 秒 | 抽了没用 |
| out_night | assets/src_clips/pexels_40806780_office_night.mp4 | 3.0 秒 | 3.4 秒 | 四天 |
| gun_killyou | assets/src_clips/acquired_killyou.mp4（Acquired 播客 NVIDIA 访谈） | 14.38 秒 | 2.22 秒（67 帧） | 只有一枪 |
| gun_perfect | assets/src_clips/acquired_perfect.mp4（Acquired 播客 NVIDIA 访谈） | 6.62 秒 | 4.03 秒（122 帧） | 只有一枪 |
| gun_conf | assets/src_clips/pexels_6951393_conference_room.mp4 | 0.5 秒 | 4.5 秒（136 帧） | 只有一枪 |
| gun_board | assets/src_clips/pexels_6754818_motherboard.mp4 | 4.0 秒 | 4.0 秒（120 帧） | 只有一枪 |
| gun_leds | assets/src_clips/pexels_7140928_server_leds.mp4 | 0.3 秒 | 5.0 秒（150 帧） | 只有一枪 |

四天另外用到：照片 assets/photos/nvidia_sign.jpg；截图 nv_letter、nv_letter_n、nv_ceo_xn、fortune_1109_16pct、cnbc_1111_postmarket、cnbc_1112_live_retail、headline_01、headline_06、nbc_1113_investigating；Blender 停留点 stops/out 的 D0b、D1、D2、D3、D3b、D3c、D4、D5b。

只有一枪另外用到：截图 vgc_sega_5m；照片 C2_1（NV1 显卡）；Blender 停留点 stops/gun 的 G01、G02、G05、G05b、G06、G06b、G08a、G08b、G09、G09b、G10、G11、G12、G12b；图「曲面对三角形」的依据是 IEEE Computer Society《Famous Graphics Chips: Nvidia’s RIVA 128》（Jon Peddie，2019-08-05）。

原声句的编号在 v10 稿子里换过，来源不变：旧 gun12q（台大，11:52–12:03）= 现在的 gun92q，源片 ntu_outofbusiness.mp4；旧 gun15q（台大，12:38–12:54）= 现在的 gun93q，源片 ntu_sixmonths.mp4；旧 gun21q（Acquired，9:08–9:31）= 现在的 gun94q，源片 acquired_perfect.mp4；开场的 kill 那一句 = 现在的 gun91q，源片 acquired_killyou.mp4。

## 正片新增（2026-11-14 深夜）

| 用在 | 原件 | 网址 | 作者 / 出版方 | 授权 | 取得日期 |
|---|---|---|---|---|---|
| 正片文件页 assets/docs/v8/cnbc_1111_centralbank.png（标题和日期行） | Analysis: Nvidia’s leadership crisis tests the chipmaker’s role as the ‘central bank of AI’（2026-11-11） | https://www.cnbc.com/2026/11/11/nvidia-jensen-huang-ai-financial-system-risk.html | CNBC | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/meta_10k_2025_ten.png（年报第 48 页一段：Class B 每股十票） | Meta Platforms 2025 年年报（10-K），原件存 assets/docs/v8/src_pdf/meta_10k_2025/ | https://d18rn0p25nwr6d.cloudfront.net/CIK-0001326801/b919eb05-86d9-4412-a8ff-308be1afb070.pdf（链接在 investor.atmeta.com 的年报页上） | Meta Platforms（SEC 公开文件） | 公开文件，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/meta_10k_2025_maj.png（年报第 36 页一句：CEO 控制过半投票权） | 同上 | 同上 | 同上 | 同上 | 2026-11-14 |
| 正片文件页 assets/docs/v8/intel_2018_ceo.png（标题） | Intel CEO Brian Krzanich Resigns, Board Appoints Bob Swan as Interim CEO（2018-06-21） | https://www.intc.com/news-events/press-releases/detail/146/intel-ceo-brian-krzanich-resigns-board-appoints-bob-swan | Intel Corporation | 公司新闻稿截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/intel_2018_rel.png（一段：past consensual relationship with an Intel employee） | 同上 | 同上 | Intel Corporation | 同上 | 2026-11-14 |
| 正片文件页 assets/docs/v8/intel_2020_q2_h.png（标题）、intel_2020_q2_seven.png（一段：7nm 推迟约六个月）、intel_2020_q2_rev.png（一条：收入 197 亿美元，同比增 20%） | Intel Reports Second-Quarter 2020 Financial Results（2020-07-23） | https://www.intc.com/news-events/press-releases/detail/1402/intel-reports-second-quarter-2020-financial-results | Intel Corporation | 公司新闻稿截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/eweek_2006_cuda.png（标题） | Nvidia Launches New Architecture for Its Graphics Chips（2006-11） | https://www.eweek.com/networking/nvidia-launches-new-architecture-for-its-graphics-chips/ | eWeek | 标题截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/lee2020_438_sent.png（摘要里一句：43.8% decrease in a firm's citation-weighted patent count）、lee2020_title.png（论文标题；用不用等主讲定） | Lee, Kim, Bae：Founder CEOs and innovation: Evidence from CEO sudden deaths in public firms，Research Policy 49(1)，2020 | https://ideas.repec.org/a/eee/respol/v49y2020i1s0048733319301817.html | 作者；RePEc IDEAS 的摘要页 | 摘要页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/fahlenbrach2009_rd.png（摘要里一句：Founder-CEO firms invest more in research and development）、fahlenbrach2009_title.png（论文标题） | Fahlenbrach：Founder-CEOs, Investment Decisions, and Stock Market Performance，JFQA 44(2)，2009 | https://doi.org/10.1017/S0022109009090139 | 作者；Cambridge Core 的摘要页 | 摘要页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/hexus_2006_cuda.png（一段：today unveiled NVIDIA CUDA technology） | NVIDIA Unveils CUDA – The GPU Computing Revolution Begins（英伟达 2006-11-08 新闻稿，HEXUS 全文转载） | https://hexus.net/qaha5 | NVIDIA（新闻稿）；HEXUS.net（转载页） | 新闻稿转载页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/fortune_2011_stoodstill.png（只截这一句：The problem was that Apple stood still） | What Steve Jobs said about Apple in the spring of ’96（2011-09-18，引 1996 年春 PBS《Wall $treet Week》） | https://fortune.com/2011/09/18/what-steve-jobs-said-about-apple-in-the-spring-of-96 | Fortune（Philip Elmer-DeWitt） | 网页截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/apple_2011_cook.png（一段：previously Apple’s Chief Operating Officer） | Steve Jobs Resigns as CEO of Apple（2011-08-24） | https://www.apple.com/newsroom/2011/08/24Steve-Jobs-Resigns-as-CEO-of-Apple/ | Apple | 公司新闻稿截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/apple_2011_letter.png（只截这一句：I strongly recommend that we execute our succession plan and name Tim Cook as CEO of Apple） | Letter from Steve Jobs（2011-08-24） | https://www.apple.com/newsroom/2011/08/24Letter-from-Steve-Jobs/ | Apple | 公司新闻稿截图，评论引用 | 2026-11-14 |
| 正片文件页 assets/docs/v8/fool_broadcom_xpu.png（11-14 深夜重截，只截这一句：Anthropic is on track to become our largest XPU customer in 2027；之前那张是坏的） | Broadcom (AVGO) Q3 2026 Earnings Call Transcript（2026-09-09） | https://www.fool.com/earnings/call-transcripts/2026/09/09/broadcom-avgo-q3-2026-earnings-call-transcript/ | The Motley Fool（逐字稿） | 网页截图，评论引用 | 2026-11-14 |

没截到的：《财富》1985-08-05 那篇（存档页 404）；Stripe 那场对话的文字稿（页面上是折叠的，截不到）；苹果 1995–1997 年的 10-K（sec.gov 不让程序访问）。这三处画面用备用方案，不出原页。
| 正片视频 assets/src_clips/gtc25_cuda.mp4（只用画面，静音；用第 2 秒以后他单人的近景） | NVIDIA GTC 2025 主旨演讲（29:57–30:10） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | NVIDIA | 版权所有，评论引用片段（主讲 2026-11-13 同意用这场演讲） | 2026-11-14 |

## 正片实拍第二批（2026-11-14 深夜，Pexels）

| 用在 | 原件 | 网址 | 作者 | 授权 | 取得日期 |
|---|---|---|---|---|---|
| 正片实拍 assets/src_clips/pexels_6951298_board_seat.mp4（谁说了算 第 7 镜（表里的 S1）） | Pexels 视频 6951298 | https://www.pexels.com/video/6951298/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_7220842_wafer_hands.mp4（谁说了算 第 29 镜（表里的 S2）） | Pexels 视频 7220842 | https://www.pexels.com/video/7220842/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_35321121_facility_night_aerial.mp4（他留下的账 第 5 镜（表里的 S1）） | Pexels 视频 35321121 | https://www.pexels.com/video/35321121/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_2376982_wafer_dies_macro.mp4（他留下的账 第 23 镜（表里的 S2）） | Pexels 视频 2376982 | https://www.pexels.com/video/2376982/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_4477613_warehouse_boxes.mp4（没人要的 CUDA 第 16 镜） | Pexels 视频 4477613 | https://www.pexels.com/video/4477613/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_5220208_oneway_night.mp4（没人要的 CUDA 第 18 镜） | Pexels 视频 5220208 | https://www.pexels.com/video/5220208/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_1085656_network_leds.mp4（最高的时候 第 6 镜） | Pexels 视频 1085656 | https://www.pexels.com/video/1085656/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_8533920_relay_4x100_mark.mp4（重估 第 13 镜（表里的 s1）） | Pexels 视频 8533920 | https://www.pexels.com/video/8533920/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |
| 正片实拍 assets/src_clips/pexels_855859_carton_conveyor.mp4（重估 第 18 镜（表里的 s2）） | Pexels 视频 855859 | https://www.pexels.com/video/855859/ | 见作品页 | Pexels License（免费使用，不要求署名） | 2026-11-14 |

## 正片各章的帧序列（续，2026-11-15）

| 帧序列（assets/clips/） | 源片 | 起点 | 长度 | 用在 |
|---|---|---|---|---|
| boom_ell_a | assets/src_clips/oracle_dinner.mp4（甲骨文官方视频，埃里森本人） | 33.2 秒（r2 起） | 3.5 秒（105 帧） | 最高的时候 |
| boom_ell_b | 同上 | 16.0 秒 | 3.3 秒（99 帧） | 最高的时候 |
| boom_dw | assets/src_clips/dwarkesh_nobeg.mp4 | 20.7 秒（r2 起） | 3.5 秒（105 帧） | 最高的时候 |
| boom_ell_c | assets/src_clips/oracle_dinner.mp4 | 23.37 秒 | 5.6 秒（168 帧） | 最高的时候 |
| boom_rog_a / boom_rog_b | assets/src_clips/rogan_insecurity.mp4 | 13.72 / 18.26 秒 | 2.3 / 1.45 秒 | 最高的时候 |
| boom_leds | assets/src_clips/pexels_1085656_network_leds.mp4 | 2.0 秒 | 4.5 秒（135 帧） | 最高的时候 |

最高的时候屏幕上的英文原话，11-15 用本机语音识别对过源片：埃里森「me and Elon begging Jensen for GPUs」「Please take our money」「take more of it」「You're not taking enough of it」；黄仁勋（Dwarkesh）「We absolutely had dinner」「In no time did they beg for GPUs」；黄仁勋（罗根 #2422）「the sense of insecurity, it doesn't leave you」。
| 正片文件页 assets/docs/v8/hkbu2020_safer.png（只截这一句：professional CEOs tend to favor safer development activities） | From the iPad and the iPhone to a… watch. What happened?（香港浸会大学工商管理学院研究简报，2020） | https://bus-research.hkbu.edu.hk/research-espresso-insights/2020/from-the-ipad-and-the-iphone-to-watch-what-happened.html | 香港浸会大学 | 网页截图，评论引用 | 2026-11-15 |
| 正片文件页 assets/docs/v8/standard_lasttime.png（一段：which might be the last time it has the opportunity to "invest in a consequential company like this"） | Nvidia CEO hints at end of investments in OpenAI, Anthropic（路透稿，The Standard 转载，2026-03-05） | https://www.thestandard.com.hk/innovation/article/325932/Nvidia-CEO-hints-at-end-of-investments-in-OpenAI-Anthropic | Reuters / The Standard | 网页截图，评论引用 | 2026-11-15 |

| 帧序列（assets/clips/） | 源片 | 起点 | 长度 | 用在 |
|---|---|---|---|---|
| rev_relay | assets/src_clips/pexels_8533920_relay_4x100_mark.mp4 | 1.0 秒 | 2.6 秒（78 帧） | 重估 |
| rev_carton | assets/src_clips/pexels_855859_carton_conveyor.mp4 | 2.4 秒 | 3.6 秒（108 帧） | 重估 |
| rev_gtc | assets/src_clips/gtc25_cuda.mp4 | 3.0 秒 | 5.6 秒（168 帧） | 重估 |
| rev_gtc_b | assets/src_clips/gtc25_cuda.mp4 | 8.4 秒 | 2.6 秒（78 帧） | 重估 |
| price_rogan_a / price_rogan_b / price_rogan_c | assets/src_clips/rogan_oneida.mp4 | 20.0 / 60.0 / 100.0 秒 | 3.0 / 4.6 / 3.0 秒 | 标价 |
| price_gsb_q / price_gsb_s | assets/src_clips/gsb_toilets.mp4 | 4.86 / 7.0 秒 | 2.6 / 4.0 秒 | 标价 |
| price_nyse | assets/src_clips/pexels_4319342_nyse_exterior.mp4 | 2.0 秒 | 3.0 秒 | 标价 |
| price_fog | assets/src_clips/pexels_855615_foggy_mountain.mp4 | 4.0 秒 | 5.8 秒 | 标价 |
| price_diner | assets/src_clips/pexels_6589392_diner.mp4 | 0 秒 | 3.2 秒 | 标价 |
| why_gtc_near60 | assets/src_clips/gtc25_morebuy.mp4 | 5.3 秒 | 60 帧（放慢用，第 6 镜中景、第 19 镜特写） | 谁说了算 |
| why_capitol | assets/src_clips/pexels_29188237_us_capitol.mp4 | 2.0 秒 | 2.8 秒（84 帧） | 谁说了算 |
| why_board | assets/src_clips/pexels_6951298_board_seat.mp4 | 1.0 秒 | 3.0 秒（90 帧），裁右半幅 | 谁说了算 |
| why_wafer | assets/src_clips/pexels_7220842_wafer_hands.mp4 | 10.0 秒 | 4.4 秒（132 帧） | 谁说了算 |
| cuda_stripe | assets/src_clips/stripe_cuda.mp4 | 2.3 秒 | 7.7 秒（231 帧） | 没人要的 CUDA |
| cuda_siepr | assets/src_clips/siepr_pain.mp4 | 4.0 秒 | 8.6 秒（258 帧） | 没人要的 CUDA |
| cuda_gpuh_a | assets/src_clips/nv_gpu_history.mp4 | 0 秒 | 2.45 秒（74 帧） | 没人要的 CUDA |
| cuda_dgx | assets/src_clips/nv_dgx1_2016.mp4 | 4.4 秒 | 2.7 秒（81 帧），画面里没有人 | 没人要的 CUDA |
| cuda_wh | assets/src_clips/pexels_4477613_warehouse_boxes.mp4 | 0.5 秒 | 3.1 秒（93 帧） | 没人要的 CUDA |
| cuda_oneway | assets/src_clips/pexels_5220208_oneway_night.mp4 | 0.5 秒 | 3.1 秒（93 帧） | 没人要的 CUDA |
| next_port_a | assets/src_clips/pexels_35907902_port_dusk.mp4 | 4.0 秒 | 1.8 秒 | 他留下的账 |
| next_fac_b | assets/src_clips/pexels_35321121_facility_night_aerial.mp4 | 0.8 秒 | 7.4 秒（三块商家招牌逐帧跟踪糊掉） | 他留下的账 |
| next_gtc_a / next_gtc_b | assets/src_clips/gtc25_5090.mp4 | 2.3 / 6.0 秒 | 3.7 / 4.0 秒 | 他留下的账 |
| next_waf | assets/src_clips/pexels_2376982_wafer_dies_macro.mp4 | 0.5 秒 | 6.0 秒 | 他留下的账 |
| next_chip | assets/src_clips/pexels_6755158_chip_closeup.mp4 | 9.0 秒 | 5.4 秒 | 他留下的账 |

## 正片配乐（score5 m3，2026-11-16；Fast Lane、HIJIRI、Claude Opus 小曲三首的授权主讲还没定）

音轨都是从 YouTube 取的（`assets/music_dl/`，清单 `manifest.json`），高频约到 15.6 kHz。使用条件照各自简介的原话抄的，没有另外核实。每首用了曲子的哪几秒、在片子的哪一句进，见 `work_v9/score5/cue_sheet_m3.md`。

| 用在 | 曲名 | 作者 / 频道 | 来源 | 简介写明的使用条件 |
|---|---|---|---|---|
| 被请下牌桌（hook）；还敢梭哈吗（allin） | Cold Case（Suspenseful Tension Music） | Soundridemusic | https://www.youtube.com/watch?v=hWHxnpGAdFs | 原话 "You can use it in videos with monetization. Just SUBSCRIBE to my channel and ADD CREDITS"；署名「Music: Cold Case by Soundridemusic」加原视频链接；不得上架流媒体 |
| 四天，不到四票（vote） | Shanghai | CjOnTheBeat（取自转载频道 Monetization - Instrumentals, Beats） | https://www.youtube.com/watch?v=3SKUSiKwB_g | CC BY 3.0（https://creativecommons.org/licenses/by/3.0/），可商用要署名；署名「Shanghai – CjOnTheBeat（https://www.youtube.com/watch?v=3SKUSiKwB_g），CC BY 3.0，剪辑过、改过音量」；人声分轨没用 |
| 两家快倒闭的公司（sega） | 战士（Chinese Koto Trap Beat） | Unknown Instrumentalz | https://www.youtube.com/watch?v=UUsNKJOVkCI | 原话 "All of my beats are 100% free to use." "I don't want any credit at all."；开头约 27 秒疑似制作人口播，没用；人声分轨没用 |
| 八亿对一千万（eight） | Fast Lane | RB Keys / Pillow Beats | https://www.youtube.com/watch?v=GWr1Op5iOTI | 原话 "For non-profit use, it's free! For any commercial/profit use, you will need a license from our site."；署名「Music provided by Pillow Beats. Instrumental: "Fast Lane" by RB Keys.」；不得登记 Content ID；**开收益前要买授权（全片唯一确定要花钱的）**；人声分轨没用，另有 5 处疑似制作人口播的残余在其他轨里，买到无口播的版本以后要重做 |
| 60 人的群，一个群主（前半，sixty1 到 5） | Taohua（中華風の穏やかなBGM） | PeriTune | https://www.youtube.com/watch?v=XUSywmokUwc | 原话「個人・商用問わず無料でお使いいただけます」，CC BY 4.0（https://creativecommons.org/licenses/by/4.0/）；署名「Taohua – PeriTune（https://www.youtube.com/watch?v=XUSywmokUwc），CC BY 4.0，剪辑过、改过音量」；禁止登记 Content ID，禁止单独分发音频；只用 12.1 到 35.4 秒（41 秒以后有合唱） |
| 60 人的群，一个群主（后半，sixty7 起）；替别人扛的一千亿（ohio） | HIJIRI（HARD ORIENTAL BEAT） | JO$HX（频道 ƁƝƁ Productions） | https://www.youtube.com/watch?v=U1hczaT2S0U | 原话 "BNB Releases can be used by any YouTube or Twitch user in their monetized content."；要在简介署名制作人（含社交链接）并附原视频链接；禁止注册发行；**抖音、B 站没写，发片前要问**；人声分轨没用 |
| 97%，追到了头（pct） | Crime is Everywhere（Dark Suspense） | Soundridemusic | https://www.youtube.com/watch?v=qHAk8jwhnOA | 原话 "You can use it in videos with monetization. Just SUBSCRIBE to my channel and ADD CREDITS"；不得上架流媒体 |
| 开场；椅子别空太久（chair） | Claude Opus 小曲 | Wenever | 主讲提供（同开场） | **没有授权**，主讲知情；开收益的视频有被认领或下架的风险；不进公开仓库 |
| 正片音效（score5 m3） | 翻页 page_turn_fast、荧光笔 underline_stroke、闷响 wood_thud（变调，垫了主音正弦）、电话和挂电话 relay_click、房间底噪 room_tone_office、图长出来 sfx_soft_impact、筹码声（type_key1 的起音加合成正弦） | 见上方 v8 音效各行；sfx_soft_impact：Rizzard | sfx_soft_impact：https://freesound.org/people/Rizzard/sounds/560156/ | CC0 1.0（Freesound） |

不花钱的排法（eight 不用 Fast Lane 时换什么、怎么接）写在 `work_v9/score5/cue_sheet_m3.md`。下载了但没用的曲子（含早先找曲版用过的 Yun Shan、Oud）也在 `assets/music_dl/`，分析结果在 `work_v9/score4/tracks.json`。

## 正片素材库 v2（2026-11-15 到 11-16 登记；下了的全记在这里，最后用没用以成片为准）

主讲 2026-11-14 同意第 9 期正片素材「自己去下就行」。下载都由总管主进程做，请求头只写项目名 chonggu-kit，遇到 403 / 429 就停，不绕。

### 采访和活动视频的片段（YouTube，只取窗口，原声可用；版权归原频道，评论引用）

| 文件（assets/src_clips/） | 取的时间段（秒） | 视频 | 频道 | 网址 | 授权 | 下载日期 |
|---|---|---|---|---|---|---|
| v2_rest/boom_him_03.mp4、v2_rest/boom_him_04.mp4 | 57–73、87–103 | NVIDIA CEO on Elon Musk, xAI, Colossus supercomputer and systems engineering ｜ Jensen Huang | Lex Clips（Lex Fridman 播客官方片段频道） | https://www.youtube.com/watch?v=5XgpESmjBqE | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_him_05.mp4、v2_rest/boom_him_06.mp4、v2_rest/boom_him_07.mp4、v2_rest/boom_him_08.mp4 | 1735–1751、1884–1900、2035–2051、2194–2210 | GTC 2023 Keynote with NVIDIA CEO Jensen Huang | NVIDIA | https://www.youtube.com/watch?v=DiGB5uAYKAg | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_him_13.mp4、v2_rest/boom_him_14.mp4、v2_rest/boom_him_15.mp4、v2_rest/boom_him_12.mp4 | 1745–1761、1861–1877、1943–1959、207–223 | NVIDIA Keynote at COMPUTEX 2023 | NVIDIA | https://www.youtube.com/watch?v=i-wpzS9ZsCs | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_him_18.mp4、v2_rest/boom_him_16.mp4、v2_rest/boom_him_17.mp4、v2_rest/boom_him_19.mp4 | 3114–3130、284–300、439–455、5979–5995 | NVIDIA GTC Washington, D.C. Keynote with CEO Jensen Huang | NVIDIA | https://www.youtube.com/watch?v=lQHK61IDFH4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_him_21.mp4、v2_rest/boom_him_20.mp4 | 19–35、1–17 | Dwarkesh Podcast 片段（黄仁勋谈那顿饭） | Dwarkesh Patel | https://www.youtube.com/watch?v=nzGjvZrWKF8 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_world_06.mp4、v2_rest/boom_world_07.mp4、v2_rest/boom_world_09.mp4、v2_rest/boom_world_11.mp4 | 104–119、144–160、439–455、546–562 | Inside the World's Largest AI Supercluster xAI Colossus | ServeTheHome | https://www.youtube.com/watch?v=Jf8EPSBZU7Y | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_world_13.mp4、v2_rest/boom_world_14.mp4、v2_rest/boom_world_15.mp4 | 14–30、47–63、1249–1263 | Oracle Financial Analyst Meeting 2024 · Q&A with Larry Ellison | Oracle | https://www.youtube.com/watch?v=O501x3Ei10Y | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_world_16.mp4、v2_rest/boom_world_17.mp4 | 0–15、23–39 | NVIDIA HGX H100 ｜ The most powerful end-to-end AI supercomputing platform | NVIDIA | https://www.youtube.com/watch?v=QGpniBJiCZw | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/boom_world_18.mp4、v2_rest/boom_world_19.mp4、v2_rest/boom_world_20.mp4 | 26–33、43–54、61–72 | Quick Tour of NVIDIA DGX H100 | NVIDIA | https://www.youtube.com/watch?v=a_tXcmEeGxo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_him1_01.mp4、v2_rest/cuda_him1_02.mp4 | 3–13、29–45 | Fireside Chat with Ilya Sutskever and Jensen Huang: AI Today and Vision of the Future | NVIDIA（官方频道），2023-05-25 | https://www.youtube.com/watch?v=-yquJiNKlAE | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_him1_03.mp4 | 4–20 | How a CEO Spends Time - Jensen Huang (NVIDIA) | Entrepreneurship.org，2011-06-24 | https://www.youtube.com/watch?v=0Bt8rXpwTvY | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_him1_08.mp4、v2_rest/cuda_him1_09.mp4、v2_rest/cuda_him1_10.mp4、v2_rest/cuda_him1_06.mp4 | 1511–1527、1689–1705、1821–1837、124–140 | A conversation with NVIDIA’s Jensen Huang | Stripe（官方频道），2024-05-21 | https://www.youtube.com/watch?v=8Pfa8kPjUio | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_him1_13.mp4、v2_rest/cuda_him1_15.mp4、v2_rest/cuda_him1_12.mp4、v2_rest/cuda_him1_14.mp4 | 35–51、94–110、7–23、83–97 | GTC 2015: The Big Bang of Deep Learning (part 5) | NVIDIA（官方频道），2015-03-18 | https://www.youtube.com/watch?v=GGxdP_JWhwI | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_him2_09.mp4、v2_rest/cuda_him2_10.mp4、v2_rest/cuda_him2_12.mp4、v2_rest/cuda_him2_14.mp4 | 0–6、7–19、27–38、52–63 | DGX Spark Arrives at SpaceX: Jensen Huang and Elon Musk Launch AI Future | NVIDIA（官方频道），2025-10-16 | https://www.youtube.com/watch?v=peaIkB0NzS0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_world1_01.mp4、v2_rest/cuda_world1_02.mp4、v2_rest/cuda_world1_03.mp4 | 0–15、29–41、54–70 | Stanford Aerial Views | Stanford（官方频道），2020-09-24 | https://www.youtube.com/watch?v=74rNgExnHfA | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_world1_18.mp4、v2_rest/cuda_world1_21.mp4 | 182–198、489–505 | MythBusters Special - Painting Robot | Discovery（官方频道），2008-09-15 | https://www.youtube.com/watch?v=iX93vj2zclM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_world1_30.mp4、v2_rest/cuda_world1_31.mp4、v2_rest/cuda_world1_32.mp4、v2_rest/cuda_world1_33.mp4 | 0–11、6–18、15–27、25–36 | GeForce 8800 GTX - 20 Years of a Legend | NVIDIA GeForce（官方频道），2026-11-05 | https://www.youtube.com/watch?v=xPsc2QOzh0I | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_world2_01.mp4、v2_rest/cuda_world2_03.mp4 | 16–32、77–93 | The Unprecedented Performance of NVIDIA’s DGX-1 for Deep Learning | NVIDIA（官方频道），2016-08-15 | https://www.youtube.com/watch?v=XumUB2wCnG8 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/cuda_world2_16.mp4、v2_rest/cuda_world2_17.mp4、v2_rest/cuda_world2_18.mp4、v2_rest/cuda_world2_20.mp4 | 2–10、28–44、43–52、58–64 | 10 Years of NVIDIA DGX | NVIDIA | https://www.youtube.com/watch?v=xAgq8ByWK0M | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_03.mp4 | 0–11 | Virtua Fighter 30th Anniversary - Video Message from NVIDIA Founder and CEO Jensen Huang | SEGA（官方频道） | https://www.youtube.com/watch?v=9NCp1BdWJG0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_04.mp4 | 154–170 | Dean's Speaker Series ｜ Jensen Huang Founder, President & CEO, NVIDIA | UC Berkeley Haas（官方频道） | https://www.youtube.com/watch?v=9hzVdV63scU | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_06.mp4、v2_rest/gun_him1_07.mp4、v2_rest/gun_him1_09.mp4、v2_rest/gun_him1_10.mp4 | 91–107、116–127、467–479、483–497 | Nvidia CEO Jensen Huang and the $2 trillion company powering today's AI ｜ 60 Minutes | 60 Minutes（CBS 官方频道） | https://www.youtube.com/watch?v=DpQQi2scsHo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_18.mp4、v2_rest/gun_him1_19.mp4、v2_rest/gun_him1_20.mp4 | 523–537、544–556、771–785 | 【完全版】エヌビディアCEO ジェンスン・フアン「来日の舞台裏」に密着！SEGAで恩人と再会、日本半導体トップと“居酒屋外交” | DIAMOND Documentary from Diamond Online（钻石社官方频道） | https://www.youtube.com/watch?v=L3Nw6alWvLs | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_21.mp4、v2_rest/rev_him1_17.mp4、v2_rest/why_him1_11.mp4 | 32–48、34–50、33–47 | Jensen Huang: Employee Selection Affects Culture | Stanford eCorner（官方频道） | https://www.youtube.com/watch?v=Pnr_TVjYlj4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_22.mp4、v2_rest/gun_him1_23.mp4、v2_rest/rev_him1_19.mp4、v2_rest/rev_him1_20.mp4、v2_rest/rev_him1_21.mp4、v2_rest/price_him_30.mp4、v2_rest/price_him_29.mp4、v2_rest/price_him_31.mp4 | 184–200、274–290、94–110、194–206、919–935、1832–1848、44–60、3344–3360 | Jensen Huang, Founder and CEO of NVIDIA | Stanford Graduate School of Business（官方频道） | https://www.youtube.com/watch?v=lXLBTBBil2U | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him1_24.mp4、v2_rest/gun_him1_25.mp4 | 94–110、164–180 | Don Valentine, Sequoia Capital: "Target Big Markets" | Stanford Graduate School of Business（官方频道） | https://www.youtube.com/watch?v=nKN-abRJMEw | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him2_02.mp4、v2_rest/gun_him2_01.mp4 | 4142–4158、3409–3425 | Caltech's 130th Commencement Ceremony | caltech（官方频道） | https://www.youtube.com/watch?v=-qXDdToZHzE | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him2_03.mp4、v2_rest/gun_him2_04.mp4、v2_rest/gun_him2_05.mp4、v2_rest/price_him_07.mp4、v2_rest/price_him_08.mp4、v2_rest/boom_him_01.mp4、v2_rest/boom_him_02.mp4 | 5044–5060、5124–5140、6294–6310、6874–6890、6938–6954、4494–4510、4584–4600 | Joe Rogan Experience #2422 - Jensen Huang | PowerfulJRE | https://www.youtube.com/watch?v=3hptKYix4X8 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him2_06.mp4、v2_rest/gun_him2_07.mp4 | 934–950、997–1013 | Jensen Huang: Founder and CEO of NVIDIA | A Bit Personal with Jodi Shelton（官方频道） | https://www.youtube.com/watch?v=8FOdAc_i_tM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_him2_20.mp4、v2_rest/gun_him2_21.mp4 | 3364–3380、5744–5760 | Jensen Huang: NVIDIA - The $4 Trillion Company & the AI Revolution ｜ Lex Fridman Podcast #494 | Lex Fridman（官方频道） | https://www.youtube.com/watch?v=vif8NQcjVf0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/gun_world_07.mp4、v2_rest/gun_world_08.mp4、v2_rest/gun_world_09.mp4、v2_rest/gun_world_10.mp4 | 0–11、0–5、0–16、3–15 | NVIDIA GPUs: 1999 to Now | NVIDIA | https://www.youtube.com/watch?v=I25dLTIPREA | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_him1_05.mp4、v2_rest/next_him1_06.mp4、v2_rest/next_him1_07.mp4、v2_rest/next_him1_08.mp4 | 0–10、185–201、364–380、581–597 | Anthropic, Microsoft, and NVIDIA Announce Partnerships | Microsoft，2025-11-18 | https://www.youtube.com/watch?v=bl7vHnOgEg0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_him1_13.mp4、v2_rest/next_him1_14.mp4、v2_rest/next_him1_15.mp4、v2_rest/next_him1_16.mp4 | 34–44、51–61、58–68、81–92 | From Groundbreaking to Game-changing: NVIDIA Blackwell Volume Production Celebration at TSMC Arizona | TSMC（官方频道），2025-10-17 | https://www.youtube.com/watch?v=kMxZguKGeBU | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_him1_20.mp4 | 179–195 | Grand Opening of GPU Tech Conference by Jen-Hsun Huang, CEO of NVIDIA | HardwareZone，2009-10-01 | https://www.youtube.com/watch?v=wg-q3aHpRTw | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_him1_22.mp4、v2_rest/next_him1_23.mp4 | 16–32、1805–1821 | Morgan Stanley TMT Conference 2026 ｜ Jensen Huang on AI, Compute, Tokens and the New Global Economy | Morgan Stanley（官方），2026-03-18 上传 | https://www.youtube.com/watch?v=xv7UVAfyebk | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_him2_01.mp4、v2_rest/next_him2_02.mp4 | 199–215、224–240 | NVIDIA CES 2015 press conference: Deep Learning (part 6) | NVIDIA，2015-01-05 | https://www.youtube.com/watch?v=-vKGkxeflGw | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world1_14.mp4、v2_rest/next_world1_15.mp4、v2_rest/next_world1_16.mp4 | 16–27、42–49、59–73 | Building the Future of AI Infrastructure with Oracle: Abilene, TX | Oracle，2025-12-01 | https://www.youtube.com/watch?v=WkkgqXrg-Xg | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world2_01.mp4、v2_rest/next_world2_02.mp4、v2_rest/next_world2_03.mp4、v2_rest/next_world2_05.mp4 | 0–10、4–13、12–19、23–31 | Columbia University in the City of New York: "A Doubled Magic" | Columbia University，2013-10-04 | https://www.youtube.com/watch?v=7cwUcdpUayQ | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world2_16.mp4 | 107–122 | The $10 Trillion AI Build-Out: Who Is Financing It? | Columbia Business School，2026-10-14 | https://www.youtube.com/watch?v=WMZBVSAMF7Y | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world2_21.mp4、v2_rest/next_world2_23.mp4 | 16–32、106–122 | Paul Goldberger on the new Goldman Sachs building in Manhattan | The New Yorker（日期未取） | https://www.youtube.com/watch?v=ntybYlsCRIU | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world2_26.mp4、v2_rest/next_world2_27.mp4、v2_rest/next_world2_28.mp4 | 1790–1806、2418–2434、2458–2474 | Building Anthropic ｜ A conversation with our co-founders | Anthropic（官方，日期未取） | https://www.youtube.com/watch?v=om2lIWXLLN4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world3_01.mp4、v2_rest/next_world3_02.mp4 | 0–8、12–22 | A First Look at NVIDIA Vera Rubin NVL72 on CoreWeave | CoreWeave（日期未取） | https://www.youtube.com/watch?v=3PeWU3Q7qvQ | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world3_04.mp4、v2_rest/next_world3_05.mp4 | 119–135、177–193 | CoreWeave Data Center in Kenilworth, NJ Exclusive Drone Footage of the Construction Site | Garden State Accountability（日期未取） | https://www.youtube.com/watch?v=IKCcA7xGILs | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world3_09.mp4、v2_rest/next_world3_10.mp4 | 37–46、46–62 | The AI Data Center Behind CoreWeave: The Essential Cloud for AI | CoreWeave，2026-02-20 | https://www.youtube.com/watch?v=MkMQj-Q0bBo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/next_world3_12.mp4 | 7–19 | Google Cloud unboxes seventh generation Ironwood TPU | Google Cloud（官方频道） | https://www.youtube.com/watch?v=coPKHrE2ATI | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_01.mp4、v2_out/out_him_02.mp4、v2_rest/gun_him1_01.mp4、v2_rest/gun_him1_02.mp4、v2_rest/rev_him1_01.mp4、v2_rest/rev_him1_02.mp4、v2_rest/price_him_01.mp4、v2_rest/price_him_02.mp4、v2_rest/price_him_03.mp4、v2_rest/price_him_04.mp4、v2_rest/why_him1_01.mp4、v2_rest/why_him1_02.mp4、v2_rest/cuda_him1_04.mp4、v2_rest/cuda_him1_05.mp4 | 1493–1517、1878–1902、1674–1690、2554–2570、1269–1285、1669–1685、14–30、164–180、324–340、1619–1635、1464–1480、1689–1705、2924–2940、3237–3253 | Oral History of Jensen Huang | Computer History Museum（官方频道） | https://www.youtube.com/watch?v=0c8i4T9BSqY | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_03.mp4、v2_rest/price_him_05.mp4、v2_rest/cuda_him2_01.mp4 | 116–134、87–103、85–101 | GTC 2016: NVIDIA DGX-1, World's First Deep Learning Supercomputer (part 7) | NVIDIA（官方） | https://www.youtube.com/watch?v=1ayGJDO6PKU | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_04.mp4、v2_out/out_him_05.mp4、v2_out/out_him_06.mp4、v2_rest/rev_him1_07.mp4、v2_rest/rev_him1_10.mp4、v2_rest/rev_him1_11.mp4、v2_rest/rev_him1_12.mp4、v2_rest/why_him1_03.mp4、v2_rest/why_him1_04.mp4、v2_rest/why_him1_05.mp4 | 104–128、132–156、168–182、99–115、235–251、332–348、467–483、104–120、139–155、375–391 | GTC 2012 Keynote (Part 1): Introduction video and welcome with NVIDIA CEO Jen-Hsun Huang | NVIDIA（官方频道） | https://www.youtube.com/watch?v=8FPQTxOTW10 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_07.mp4、v2_rest/gun_him2_09.mp4、v2_rest/gun_him2_10.mp4、v2_rest/gun_him2_08.mp4 | 26–50、264–280、359–375、4–20 | 2026 CMU Commencement Keynote Speaker: Jensen Huang | Carnegie Mellon University（官方频道） | https://www.youtube.com/watch?v=FZh_0uRgrg4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_08.mp4、v2_out/out_him_09.mp4、v2_out/out_him_11.mp4、v2_rest/why_him2_01.mp4、v2_rest/why_him2_02.mp4、v2_rest/why_him2_04.mp4、v2_rest/why_him2_08.mp4 | 27–42、76–94、1586–1605、0–13、29–43、77–93、285–301 | The Rise and Reckoning of Jensen Huang, The Circuit with Emily Chang | Bloomberg Originals | https://www.youtube.com/watch?v=JW5s9Md4U2U | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_12.mp4 | 46–68 | The Engadget Interview: NVIDIA CEO Jen-Hsun Huang | Engadget | https://www.youtube.com/watch?v=JZShrhB7Cr4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_13.mp4、v2_out/out_him_14.mp4、v2_out/out_him_15.mp4、v2_out/out_him_16.mp4、v2_rest/gun_him2_12.mp4、v2_rest/gun_him2_13.mp4、v2_rest/gun_him2_11.mp4、v2_rest/gun_him2_14.mp4、v2_rest/rev_him2_04.mp4、v2_rest/rev_him2_05.mp4、v2_rest/rev_him2_07.mp4 | 203–227、263–287、410–434、7858–7882、311–327、399–415、267–283、7504–7520、314–330、414–430、3057–3073 | GTC March 2025 Keynote with NVIDIA CEO Jensen Huang | NVIDIA（官方频道） | https://www.youtube.com/watch?v=_waPvOwL9Z8 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_17.mp4、v2_out/out_him_18.mp4、v2_out/out_him_19.mp4、v2_out/out_him_20.mp4、v2_rest/rev_world1_34.mp4、v2_rest/rev_world1_35.mp4、v2_rest/rev_world1_37.mp4、v2_rest/price_world1_18.mp4、v2_rest/price_world1_19.mp4、v2_rest/price_world1_21.mp4、v2_rest/why_world1_17.mp4、v2_rest/why_world1_18.mp4、v2_rest/cuda_world2_08.mp4、v2_rest/cuda_world2_09.mp4 | 6–28、24–48、48–64、86–102、4–20、24–40、85–100、4–20、23–39、87–100、4–20、23–39、4–20、23–39 | Ready for Liftoff | NVIDIA（官方频道） | https://www.youtube.com/watch?v=hj0uY0yDOwM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_22.mp4、v2_out/out_him_23.mp4、v2_out/out_him_21.mp4 | 156–174、181–199、105–116 | NVIDIA Solutions Bring New Headquarters Building to Life | NVIDIA | https://www.youtube.com/watch?v=iCKx8LidOdM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_24.mp4、v2_out/out_him_25.mp4、v2_out/out_him_26.mp4、v2_rest/why_him1_15.mp4、v2_rest/why_him1_16.mp4、v2_rest/why_him1_17.mp4 | 196–220、260–284、364–388、177–193、231–247、6794–6810 | GTC Europe 2016 - Keynote | NVIDIA | https://www.youtube.com/watch?v=npzRyTimcZo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_28.mp4、v2_out/out_him_29.mp4、v2_out/out_him_27.mp4、v2_out/out_him_30.mp4、v2_rest/rev_him1_23.mp4、v2_rest/rev_him1_24.mp4、v2_rest/rev_him1_25.mp4、v2_rest/price_world1_26.mp4、v2_rest/price_world1_28.mp4、v2_rest/price_world1_29.mp4、v2_rest/why_world1_25.mp4、v2_rest/why_world1_26.mp4、v2_rest/cuda_world2_13.mp4、v2_rest/next_world1_31.mp4、v2_rest/next_world1_33.mp4、v2_rest/next_world1_34.mp4 | 26–38、394–410、7–27、439–448、43–57、157–173、394–409、43–55、72–88、396–409、42–53、71–87、43–54、8–24、43–55、72–88 | Inside Nvidia HQ: What a $2T Company’s Office Looks Like ｜ WSJ Open Office | The Wall Street Journal | https://www.youtube.com/watch?v=qDg_3eqssig | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_32.mp4、v2_out/out_him_33.mp4、v2_out/out_him_31.mp4、v2_out/out_him_34.mp4、v2_rest/why_him1_18.mp4、v2_rest/why_him1_19.mp4 | 16–36、34–52、6–22、60–82、0–16、88–104 | GPU Technology Conference 2014: Opening, NVLink (part 1) GTC | NVIDIA | https://www.youtube.com/watch?v=qaJGfWDFo74 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_35.mp4、v2_out/out_him_37.mp4、v2_out/out_him_36.mp4、v2_rest/gun_him2_15.mp4、v2_rest/gun_him2_16.mp4、v2_rest/gun_him2_18.mp4、v2_rest/gun_him2_19.mp4、v2_rest/why_him1_20.mp4、v2_rest/why_him1_22.mp4、v2_rest/why_him1_21.mp4、v2_rest/cuda_him1_22.mp4 | 424–442、813–837、773–797、514–530、564–580、654–670、874–890、811–827、2989–3005、865–881、514–530 | Morris Chang, in conversation with Jen-Hsun Huang | Computer History Museum（官方频道） | https://www.youtube.com/watch?v=u-x7PdnvCyI | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_39.mp4、v2_out/out_him_41.mp4、v2_out/out_him_38.mp4、v2_out/out_him_42.mp4、v2_rest/rev_him1_34.mp4、v2_rest/rev_him1_35.mp4、v2_rest/rev_him1_37.mp4、v2_rest/why_him1_25.mp4、v2_rest/why_him1_26.mp4、v2_rest/why_him1_27.mp4、v2_rest/next_him2_08.mp4、v2_rest/next_him2_09.mp4、v2_rest/next_him2_10.mp4、v2_rest/next_him2_11.mp4、v2_rest/boom_him_22.mp4、v2_rest/boom_him_24.mp4、v2_rest/boom_him_23.mp4 | 254–278、4986–5006、168–192、5487–5511、204–220、999–1015、4734–4750、194–210、1004–1020、1044–1060、854–870、1044–1060、1075–1091、1257–1273、195–211、439–455、354–370 | NVIDIA GTC Berlin 2026 Keynote With CEO Jensen Huang | NVIDIA | https://www.youtube.com/watch?v=v-NGxyPjcrE | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_43.mp4、v2_rest/gun_him1_26.mp4、v2_rest/gun_him1_27.mp4、v2_rest/gun_him1_28.mp4、v2_rest/cuda_him1_26.mp4、v2_rest/cuda_him1_27.mp4、v2_rest/cuda_him1_23.mp4、v2_rest/cuda_him1_24.mp4 | 564–582、394–410、539–555、594–610、5007–5023、5054–5070、1109–1125、1242–1258 | NVIDIA CEO Jensen Huang | Acquired（Ben Gilbert、David Rosenthal） | https://www.youtube.com/watch?v=y6NfxiemvHg | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_him_44.mp4、v2_rest/boom_him_25.mp4、v2_rest/boom_him_26.mp4 | 13–37、7–23、134–150 | Jensen Huang-The First Six Months of NVIDIA | Entrepreneurship.org | https://www.youtube.com/watch?v=yU3GUHDf0mk | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_04.mp4、v2_out/out_world_05.mp4、v2_out/out_world_06.mp4、v2_out/out_world_07.mp4、v2_out/out_world_08.mp4、v2_rest/price_world1_02.mp4、v2_rest/price_world1_04.mp4、v2_rest/price_world1_01.mp4、v2_rest/price_world1_03.mp4、v2_rest/why_world1_02.mp4 | 13–23、34–49、68–84、181–195、192–202、36–48、73–89、11–21、58–71、35–51 | Nasdaq MarketSite | Nasdaq（官方频道） | https://www.youtube.com/watch?v=4YRfh1PuatQ | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_09.mp4、v2_out/out_world_10.mp4、v2_out/out_world_11.mp4、v2_out/out_world_12.mp4 | 53–69、123–147、1381–1404、6733–6757 | AMD Advancing AI Keynote | AMD | https://www.youtube.com/watch?v=5dmFa9iXPWI | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_18.mp4、v2_out/out_world_19.mp4 | 20–39、103–127 | Bloomberg by Foster + Partners | Foster + Partners | https://www.youtube.com/watch?v=9TMppk_Y5kY | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_20.mp4、v2_out/out_world_21.mp4、v2_out/out_world_22.mp4 | 25–49、48–70、71–84 | Broadcom Product Demo: Tomahawk 6 Ethernet Switch for Next-Gen AI Networks | Broadcom Inc. | https://www.youtube.com/watch?v=HdAiOT_P1Lo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_24.mp4、v2_out/out_world_23.mp4 | 3253–3277、226–250 | AMD at Computex 2024: AMD AI and High-Performance Computing with Dr. Lisa Su | AMD | https://www.youtube.com/watch?v=MCi8jgALPYA | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_25.mp4、v2_out/out_world_27.mp4、v2_out/out_world_28.mp4、v2_out/out_world_29.mp4、v2_out/out_world_26.mp4 | 338–362、1083–1107、1258–1282、6168–6192、963–987 | LIVE: Nasdaq Opening Bell Rings as Nvidia CEO Jensen Huang Faces Leadership Uncertainty | News Central | https://www.youtube.com/watch?v=Mwxz4Bk5Jp4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_out/out_world_30.mp4、v2_out/out_world_31.mp4、v2_out/out_world_32.mp4、v2_out/out_world_33.mp4 | 103–127、210–234、270–284、345–369 | The NYTimes Building: Masterpiece or Monstrosity? | Magnitudes | https://www.youtube.com/watch?v=SPtT-6xwV_0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_him_09.mp4、v2_rest/price_him_10.mp4、v2_rest/price_him_12.mp4、v2_rest/price_him_11.mp4 | 819–835、897–913、1017–1033、984–1000 | GeForce GTX 1080 Ti - Official Launch Presentation from Jen-Hsun Huang | NVIDIA GeForce（官方） | https://www.youtube.com/watch?v=L9ZSnI9woWg | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_him_16.mp4、v2_rest/price_him_17.mp4、v2_rest/price_him_18.mp4、v2_rest/price_him_19.mp4、v2_rest/cuda_him2_04.mp4、v2_rest/next_him1_04.mp4 | 7–23、31–47、59–75、1185–1201、7–23、69–85 | GTC 2015: NVIDIA CEO Jen-Hsun Huang Interviews Tesla Motors CEO Elon Musk (part 9) | NVIDIA（官方） | https://www.youtube.com/watch?v=TDm6Snkle70 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_him_22.mp4、v2_rest/price_him_23.mp4、v2_rest/cuda_him1_16.mp4、v2_rest/cuda_him1_17.mp4、v2_rest/cuda_him1_18.mp4 | 411–427、446–462、409–425、2294–2310、3220–3236 | Keynote by NVIDIA CEO Jensen Huang at 2024 SIEPR Economic Summit | Stanford Institute for Economic Policy Research | https://www.youtube.com/watch?v=cEg8cOx7UZk | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_him_24.mp4、v2_rest/price_him_25.mp4、v2_rest/price_him_26.mp4、v2_rest/price_him_27.mp4 | 1–14、26–35、75–88、85–101 | Huang Engineering Center Dedicated | Stanford（官方） | https://www.youtube.com/watch?v=gyCvd6XBvlo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_world1_13.mp4、v2_rest/price_world1_14.mp4、v2_rest/price_world1_15.mp4 | 149–165、179–195、225–241 | Meta Connect 2025 Keynote | Meta（官方） | https://www.youtube.com/watch?v=Q9eLemEd9FY | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_world1_16.mp4、v2_rest/price_world1_17.mp4 | 4379–4395、4514–4530 | LIVE: Nvidia stock price as Jensen Huang resigns as CEO | Associated Press | https://www.youtube.com/watch?v=gtwLDkTpLyc | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_world1_31.mp4、v2_rest/price_world1_32.mp4、v2_rest/price_world1_33.mp4 | 224–239、236–252、251–267 | Larry Ellison, CEO, Oracle: OpenWorld 2010 Highlights 9.19.10 | Oracle Video（官方） | https://www.youtube.com/watch?v=tWB0fR-buJ4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_world2_01.mp4、v2_rest/price_world2_03.mp4、v2_rest/price_world2_05.mp4、v2_rest/price_world2_08.mp4 | 0–16、97–113、132–148、358–374 | The Denny’s Booth That Launched A Multi-Trillion Dollar Company | StanfordJournalism（斯坦福新闻项目 Peninsula Press） | https://www.youtube.com/watch?v=KpD_XKxJwcU | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/price_world2_11.mp4、v2_rest/price_world2_12.mp4 | 88–104、108–124 | Chris Malachowsky: Founder & Fellow @NVIDIA, A 30-Year Roadmap to Change the World ｜ Slush 2024 | Slush（官方） | https://www.youtube.com/watch?v=mbWQAs7ihC4 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_him1_26.mp4、v2_rest/rev_him1_27.mp4、v2_rest/rev_him1_29.mp4、v2_rest/rev_him1_30.mp4 | 0–13、16–25、123–131、184–200 | Jensen Huang’s Keynote Highlights at NVIDIA GTC Berlin 2026 | NVIDIA（官方频道） | https://www.youtube.com/watch?v=rF1EsryCAwc | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_him2_09.mp4、v2_rest/rev_him2_10.mp4、v2_rest/cuda_him1_20.mp4、v2_rest/cuda_him1_21.mp4、v2_rest/cuda_him1_19.mp4 | 16–32、87–103、14–30、44–60、2–18 | GTC 2016: GPU-Accelerated Computing Changing the World (part 1) | NVIDIA（官方频道） | https://www.youtube.com/watch?v=ddBIF1fnvIM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_him2_15.mp4、v2_rest/rev_him2_17.mp4 | 544–560、2881–2897 | NVIDIA Keynote | CES（大会官方频道） | https://www.youtube.com/watch?v=fkJB9owifEc | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_him2_19.mp4、v2_rest/rev_him2_20.mp4、v2_rest/rev_him2_21.mp4 | 6–18、35–45、87–103 | NVIDIA GTC 2026 Keynote with Jensen Huang Highlights | NVIDIA（官方频道） | https://www.youtube.com/watch?v=kDd24YOeqQQ | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_world1_02.mp4、v2_rest/rev_world1_03.mp4、v2_rest/rev_world1_06.mp4、v2_rest/rev_world1_07.mp4 | 301–317、342–358、502–518、534–550 | Steve Jobs Introduces the Macintosh | Computer History Museum（官方频道） | https://www.youtube.com/watch?v=1tQ5XwvjPmA | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_world1_17.mp4、v2_rest/rev_world1_18.mp4、v2_rest/rev_world1_20.mp4、v2_rest/rev_world1_21.mp4 | 16–32、89–105、175–191、276–290 | Introducing Azure Maia 300 | Microsoft Azure（官方频道） | https://www.youtube.com/watch?v=DkzQGISPBow | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_world1_29.mp4、v2_rest/rev_world1_30.mp4、v2_rest/rev_world1_31.mp4、v2_rest/rev_world1_33.mp4、v2_rest/next_world1_20.mp4、v2_rest/next_world1_21.mp4、v2_rest/next_world1_23.mp4、v2_rest/next_world1_25.mp4 | 5–18、34–50、87–103、151–161、6–18、35–51、105–119、151–163 | The NVIDIA Rubin Platform: Six New Chips, One AI Supercomputer | NVIDIA（官方频道） | https://www.youtube.com/watch?v=e3PIvqig1MM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_world2_02.mp4 | 23–36 | The World of Advanced Packaging | Applied Materials（官方频道） | https://www.youtube.com/watch?v=-egYoxajTz0 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/rev_world2_11.mp4 | 57–71 | TSMC 3DFabric™: Industry-leading 3D Silicon Stacking and Advanced Packaging Technologies | TSMC（官方频道） | https://www.youtube.com/watch?v=CjWJvBPnmxE | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_him1_08.mp4、v2_rest/why_him1_09.mp4、v2_rest/why_him1_10.mp4 | 24–40、74–90、537–553 | Jensen Huang: The Mindset That Built NVIDIA | Y Combinator | https://www.youtube.com/watch?v=I4B37S1dyQQ | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world1_14.mp4、v2_rest/next_world1_17.mp4、v2_rest/next_world1_18.mp4、v2_rest/next_world1_19.mp4 | 35–49、0–9、16–27、33–44 | Aerial Tour of New NVIDIA HQ Building | NVIDIA，2016-11-02 | https://www.youtube.com/watch?v=XE3wCTwbQYo | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world1_21.mp4 | 24–40 | Mark Zuckerberg Delivers Keynote Address At Facebook's F8 Developer Conference ｜ TIME | TIME | https://www.youtube.com/watch?v=mKYpm3OFcvY | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world1_30.mp4、v2_rest/why_world1_31.mp4、v2_rest/why_world1_32.mp4 | 117–133、149–165、249–265 | F8 2019 Day 1 Keynote | Meta Developers | https://www.youtube.com/watch?v=xK0RwubFi-U | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world2_15.mp4 | 243–256 | The History of the United States Capitol | Architect of the Capitol | https://www.youtube.com/watch?v=jmo-A_8HoOM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world2_25.mp4、v2_rest/why_world2_26.mp4、v2_rest/why_world2_27.mp4、v2_rest/why_world2_29.mp4 | 207–223、265–281、625–641、5527–5543 | Intel Keynote | CES | https://www.youtube.com/watch?v=viezeQZjZRI | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world3_01.mp4、v2_rest/why_world3_03.mp4、v2_rest/why_world3_04.mp4 | 28–40、67–81、90–106 | Take A Sneak Peek Inside an Intel Sub Fab | Intel Newsroom | https://www.youtube.com/watch?v=8jpRADL3BGM | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world3_08.mp4、v2_rest/why_world3_09.mp4、v2_rest/why_world3_10.mp4 | 0–5、7–18、22–36 | Working In The Clean Room Inside The Fab ｜ Intel | Intel | https://www.youtube.com/watch?v=WVLGKq9An28 | 版权所有，评论引用片段 | 2026-11-15 |
| v2_rest/why_world3_12.mp4、v2_rest/why_world3_17.mp4 | 27–42、418–434 | Intel keynote at Computex 2019 in 11 minutes | Engadget | https://www.youtube.com/watch?v=u4G_41DSfQQ | 版权所有，评论引用片段 | 2026-11-15 |

### 维基共享资源的照片（assets/photos/commons_v2/）

| 文件 | 原题 | 页面 | 作者 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| boom_ellison_on_stage_2.jpg | File:Larry Ellison on stage (2).jpg | https://commons.wikimedia.org/wiki/File:Larry_Ellison_on_stage_(2).jpg | Oracle PR | CC BY 2.0 | 2026-11-15 |
| boom_ellison_on_stage_4.jpg | File:Larry Ellison on stage (4).jpg | https://commons.wikimedia.org/wiki/File:Larry_Ellison_on_stage_(4).jpg | Oracle PR | CC BY 2.0 | 2026-11-15 |
| boom_ellison_openworld_2010.jpg | File:Larry Ellison in Oracle OpenWorld 2010.JPG | https://commons.wikimedia.org/wiki/File:Larry_Ellison_in_Oracle_OpenWorld_2010.JPG | Ilan Costica | CC BY-SA 3.0 | 2026-11-15 |
| boom_nobu_palo_alto_1.jpg | File:Nobu Hotel Exterior in Palo Alto.jpg | https://commons.wikimedia.org/wiki/File:Nobu_Hotel_Exterior_in_Palo_Alto.jpg | BrokenSegue | CC BY-SA 4.0 | 2026-11-15 |
| boom_nobu_palo_alto_2.jpg | File:Nobu restaurant in Palo Alto (31 January 2021).jpg | https://commons.wikimedia.org/wiki/File:Nobu_restaurant_in_Palo_Alto_(31_January_2021).jpg | LittleT889 | CC BY-SA 4.0 | 2026-11-15 |
| boom_supermicro_gpu_server_1.png | File:Client Project Hashcat Testing With an AMD Epyc Supermicro Nvidia GPU Server Using Proxmox (Lawrence Systems) 02.png | https://commons.wikimedia.org/wiki/File:Client_Project_Hashcat_Testing_With_an_AMD_Epyc_Supermicro_Nvidia_GPU_Server_Using_Proxmox_(Lawrence_Systems)_02.png | Lawrence Systems | CC BY 3.0 | 2026-11-15 |
| cuda_geforce_8800_gtx_1.jpg | File:NVIDIA GeForce 8800 GTX Board.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_GeForce_8800_GTX_Board.jpg | Hyins | Public domain | 2026-11-15 |
| cuda_geforce_8800_gtx_3.jpg | File:NVIDIA G80 GPU.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_G80_GPU.jpg | Hyins | Public domain | 2026-11-15 |
| cuda_geforce_8_series_1.png | File:NVIDIA GeForce 8800 Ultra.png | https://commons.wikimedia.org/wiki/File:NVIDIA_GeForce_8800_Ultra.png | Hyins | Public domain | 2026-11-15 |
| cuda_geforce_8_series_4.jpg | File:NVIDIA GeForce 8800 Ultra Board.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_GeForce_8800_Ultra_Board.jpg | Hyins | Public domain | 2026-11-15 |
| cuda_geforce_gtx_580_2.jpg | File:NVIDIA@40nm@Fermi@GF110@GeForce GTX 580@UA10B338 1041A1 N2Y540.000 GF110-375-A1 DSC06727 (28114557571).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@40nm@Fermi@GF110@GeForce_GTX_580@UA10B338_1041A1_N2Y540.000_GF110-375-A1_DSC06727_(28114557571).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-15 |
| cuda_geforce_gtx_580_3.jpg | File:NVIDIA@40nm@Fermi@GF110@GeForce GTX 580@UA10B338 1041A1 N2Y540.000 GF110-375-A1 DSC04152 (27576804994).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@40nm@Fermi@GF110@GeForce_GTX_580@UA10B338_1041A1_N2Y540.000_GF110-375-A1_DSC04152_(27576804994).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-15 |
| cuda_geoffrey_hinton_2.jpg | File:Geoffrey Hinton in 2026.jpg | https://commons.wikimedia.org/wiki/File:Geoffrey_Hinton_in_2026.jpg | Cmichel67 | CC BY-SA 4.0 | 2026-11-15 |
| cuda_geoffrey_hinton_4.jpg | File:Geoffrey Hinton - Collision 2023 - Centre Stage RCZ 1307 (cropped).jpg | https://commons.wikimedia.org/wiki/File:Geoffrey_Hinton_-_Collision_2023_-_Centre_Stage_RCZ_1307_(cropped).jpg | Ramsey Cardy / Collision via Sportsfile | CC BY 2.0 | 2026-11-15 |
| cuda_titan_supercomputer_oak_ridg_1.jpg | File:Titan, 2013 (49912802521).jpg | https://commons.wikimedia.org/wiki/File:Titan,_2013_(49912802521).jpg | OLCF at ORNL | CC BY 2.0 | 2026-11-15 |
| cuda_wall_street_bull_2.jpg | File:Bull Wall Street (6173547669).jpg | https://commons.wikimedia.org/wiki/File:Bull_Wall_Street_(6173547669).jpg | Bruno Sanchez-Andrade Nuño from Washington, DC, USA | CC BY 2.0 | 2026-11-15 |
| cuda_wall_street_bull_3.jpg | File:Wall Street bull (15467605171).jpg | https://commons.wikimedia.org/wiki/File:Wall_Street_bull_(15467605171).jpg | vagueonthehow from Tadcaster, York, England | CC BY 2.0 | 2026-11-15 |
| gun_3dfx_voodoo_2.jpg | File:2theMAX 3dfx voodoo rush.jpg | https://commons.wikimedia.org/wiki/File:2theMAX_3dfx_voodoo_rush.jpg | Elmepi | CC BY-SA 4.0 | 2026-11-15 |
| gun_3dfx_voodoo_3.jpg | File:3Dfx@Voodoo Graphics FrontsideA.jpg | https://commons.wikimedia.org/wiki/File:3Dfx@Voodoo_Graphics_FrontsideA.jpg | FritzchensFritz | CC0 | 2026-11-15 |
| gun_diamond_edge_3d_1.jpg | File:Diamond Edge 3D 3400.jpg | https://commons.wikimedia.org/wiki/File:Diamond_Edge_3D_3400.jpg | Hyins at Chinese Wikipedia | Public domain | 2026-11-15 |
| gun_diamond_edge_3d_2.jpg | File:Dedge3d.jpg | https://commons.wikimedia.org/wiki/File:Dedge3d.jpg | Swaaye at English Wikipedia | CC BY-SA 3.0 | 2026-11-15 |
| gun_geforce_256_1.png | File:Canopus GeForce 256 DDR.png | https://commons.wikimedia.org/wiki/File:Canopus_GeForce_256_DDR.png | Hyins | Public domain | 2026-11-15 |
| gun_geforce_256_2.jpg | File:VisionTek GeForce 256.jpg | https://commons.wikimedia.org/wiki/File:VisionTek_GeForce_256.jpg | Hyins | Public domain | 2026-11-15 |
| gun_geforce_256_3.jpg | File:KL NVIDIA Geforce 256.jpg | https://commons.wikimedia.org/wiki/File:KL_NVIDIA_Geforce_256.jpg | Konstantin Lanzet | CC BY-SA 3.0 | 2026-11-15 |
| gun_geforce_256_4.jpg | File:NVIDIA@220nm@Fixed-pipline@NV10@GeForce 256@T5A3202220008 S1 Taiwan A DSC01375 (29587991824).jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@220nm@Fixed-pipline@NV10@GeForce_256@T5A3202220008_S1_Taiwan_A_DSC01375_(29587991824).jpg | Fritzchens Fritz from Berlin | CC0 | 2026-11-15 |
| gun_nvidia_nv1_3.jpg | File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X B A22CI9601 MALTA DSCx14 polysilicon@makrolens.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X_B_A22CI9601_MALTA_DSCx14_polysilicon@makrolens.jpg | FritzchensFritz | CC0 | 2026-11-15 |
| gun_nvidia_nv1_4.jpg | File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X B A22CI9601 MALTA DSCx10 top metal@5x.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X_B_A22CI9601_MALTA_DSCx10_top_metal@5x.jpg | FritzchensFritz | CC0 | 2026-11-15 |
| gun_nvidia_riva_tnt_1.jpg | File:RIVA TNT GPU.jpg | https://commons.wikimedia.org/wiki/File:RIVA_TNT_GPU.jpg | Hyins | Public domain | 2026-11-15 |
| gun_nvidia_riva_tnt_2.png | File:Canopus RIVA TNT.png | https://commons.wikimedia.org/wiki/File:Canopus_RIVA_TNT.png | Hyins | Public domain | 2026-11-15 |
| gun_riva_128_1.jpg | File:Elsa Victory Erazor-AGP-4 - Nvidia RIVA 128-7094.jpg | https://commons.wikimedia.org/wiki/File:Elsa_Victory_Erazor-AGP-4_-_Nvidia_RIVA_128-7094.jpg | Raimond Spekking | CC BY-SA 4.0 | 2026-11-15 |
| gun_riva_128_2.jpg | File:RIVA 128ZX GPU.jpg | https://commons.wikimedia.org/wiki/File:RIVA_128ZX_GPU.jpg | Hyins | Public domain | 2026-11-15 |
| gun_riva_128_3.jpg | File:RIVA 128 GPU.jpg | https://commons.wikimedia.org/wiki/File:RIVA_128_GPU.jpg | Hyins | Public domain | 2026-11-15 |
| gun_riva_128_4.jpg | File:RIVA 128 NV GPU.jpg | https://commons.wikimedia.org/wiki/File:RIVA_128_NV_GPU.jpg | Hyins | Public domain | 2026-11-15 |
| gun_sand_hill_road_menlo_park_1.jpg | File:Sand Hill Road Eastbound View.jpg | https://commons.wikimedia.org/wiki/File:Sand_Hill_Road_Eastbound_View.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| gun_sand_hill_road_menlo_park_2.jpg | File:Sand Hill Road Freeway Exit.jpg | https://commons.wikimedia.org/wiki/File:Sand_Hill_Road_Freeway_Exit.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| gun_sega_saturn_console_1.jpg | File:Sega-Saturn-Console-Set-Mk2.jpg | https://commons.wikimedia.org/wiki/File:Sega-Saturn-Console-Set-Mk2.jpg | Evan-Amos | CC BY-SA 3.0 | 2026-11-15 |
| gun_sega_saturn_console_2.png | File:Sega-Saturn-Console-Set-Mk1.png | https://commons.wikimedia.org/wiki/File:Sega-Saturn-Console-Set-Mk1.png | Evan-Amos | Public domain | 2026-11-15 |
| gun_sega_saturn_console_3.png | File:Sega-Saturn-JP-Mk2-Console-Set.png | https://commons.wikimedia.org/wiki/File:Sega-Saturn-JP-Mk2-Console-Set.png | Evan-Amos | Public domain | 2026-11-15 |
| gun_sega_saturn_motherboard_1.jpg | File:Sega-Saturn-Motherboard-Model-VASG-Top.jpg | https://commons.wikimedia.org/wiki/File:Sega-Saturn-Motherboard-Model-VASG-Top.jpg | Evan-Amos | Public domain | 2026-11-15 |
| gun_sega_saturn_motherboard_4.jpg | File:Sega-Saturn-US-Motherboard-M2-01.jpg | https://commons.wikimedia.org/wiki/File:Sega-Saturn-US-Motherboard-M2-01.jpg | Evan-Amos | Public domain | 2026-11-15 |
| gun_sgs_thomson_stg2000_1.jpg | File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X B A22CI9601 MALTA DSCx4.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA@500nm@Fixed-pipeline@NV1@STG2000X_B_A22CI9601_MALTA_DSCx4.jpg | FritzchensFritz | CC0 | 2026-11-15 |
| gun_silicon_graphics_workstation_2.jpg | File:Silicon Graphics Indy.jpg | https://commons.wikimedia.org/wiki/File:Silicon_Graphics_Indy.jpg | Bilby | CC BY 3.0 | 2026-11-15 |
| gun_silicon_graphics_workstation_3.jpg | File:Silicon Graphics Tezro Workstation.jpg | https://commons.wikimedia.org/wiki/File:Silicon_Graphics_Tezro_Workstation.jpg | Telecineguy | CC BY-SA 3.0 | 2026-11-15 |
| gun_virtua_fighter_arcade_cabine_1.jpg | File:Virtua Fighter 2 2026-08-14.jpg | https://commons.wikimedia.org/wiki/File:Virtua_Fighter_2_2026-08-14.jpg | GuiltyGearFan37 | CC0 | 2026-11-15 |
| next_microsoft_data_center_1.jpg | File:Microsoft Data Center Middenmeer, the Netherlands - 2.jpg | https://commons.wikimedia.org/wiki/File:Microsoft_Data_Center_Middenmeer,_the_Netherlands_-_2.jpg | Hay Kranen | CC BY 4.0 | 2026-11-15 |
| next_microsoft_data_center_2.jpg | File:Microsoft Data Center Middenmeer, the Netherlands - 1.jpg | https://commons.wikimedia.org/wiki/File:Microsoft_Data_Center_Middenmeer,_the_Netherlands_-_1.jpg | Hay Kranen | CC BY 4.0 | 2026-11-15 |
| next_nvidia_blackwell_2.jpg | File:Jensen Huang - RTX Blackwell - Nvidia Keynote - CES 2025 Las Vegas (3).jpg | https://commons.wikimedia.org/wiki/File:Jensen_Huang_-_RTX_Blackwell_-_Nvidia_Keynote_-_CES_2025_Las_Vegas_(3).jpg | Pronoia | CC0 | 2026-11-15 |
| next_nvidia_blackwell_3.jpg | File:Jensen Huang - RTX Blackwell - Nvidia Keynote - CES 2025 Las Vegas (2).jpg | https://commons.wikimedia.org/wiki/File:Jensen_Huang_-_RTX_Blackwell_-_Nvidia_Keynote_-_CES_2025_Las_Vegas_(2).jpg | Pronoia | CC0 | 2026-11-15 |
| next_nvidia_h100_1.png | File:NVIDIA H100 (极客湾Geekerwan) 024.png | https://commons.wikimedia.org/wiki/File:NVIDIA_H100_(%E6%9E%81%E5%AE%A2%E6%B9%BEGeekerwan)_024.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-15 |
| next_nvidia_h100_2.png | File:NVIDIA H100 (极客湾Geekerwan) 021.png | https://commons.wikimedia.org/wiki/File:NVIDIA_H100_(%E6%9E%81%E5%AE%A2%E6%B9%BEGeekerwan)_021.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-15 |
| next_nvidia_h100_3.png | File:NVIDIA H100 (极客湾Geekerwan) 014.png | https://commons.wikimedia.org/wiki/File:NVIDIA_H100_(%E6%9E%81%E5%AE%A2%E6%B9%BEGeekerwan)_014.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-15 |
| next_openai_headquarters_san_fran_1.jpg | File:Pioneer Building, San Francisco (2019) -1.jpg | https://commons.wikimedia.org/wiki/File:Pioneer_Building,_San_Francisco_(2019)_-1.jpg | HaeB | CC BY-SA 4.0 | 2026-11-15 |
| next_openai_headquarters_san_fran_2.jpg | File:1515 Third Street.jpg | https://commons.wikimedia.org/wiki/File:1515_Third_Street.jpg | Coolcaesar | CC BY 4.0 | 2026-11-15 |
| next_satya_nadella_2024_1.jpg | File:MS-Exec-Nadella-Satya-2017-08-31-22 (cropped).jpg | https://commons.wikimedia.org/wiki/File:MS-Exec-Nadella-Satya-2017-08-31-22_(cropped).jpg | Brian Smale and Microsoft | CC BY-SA 4.0 | 2026-11-15 |
| next_sk_hynix_1.jpg | File:SK Hynix DDR5 Tall MRDIMM.jpg | https://commons.wikimedia.org/wiki/File:SK_Hynix_DDR5_Tall_MRDIMM.jpg | 4300streetcar | CC BY 4.0 | 2026-11-15 |
| next_sk_hynix_2.jpg | File:SK Hynix DDR5 form factors.jpg | https://commons.wikimedia.org/wiki/File:SK_Hynix_DDR5_form_factors.jpg | 4300streetcar | CC BY 4.0 | 2026-11-15 |
| next_tsmc_fab_hsinchu_1.jpg | File:TSMC fabs in Hsinchu 01.jpg | https://commons.wikimedia.org/wiki/File:TSMC_fabs_in_Hsinchu_01.jpg | 曾 成訓 | CC BY 2.0 | 2026-11-15 |
| next_tsmc_fab_hsinchu_2.jpg | File:TSMC fabs in Hsinchu 02.jpg | https://commons.wikimedia.org/wiki/File:TSMC_fabs_in_Hsinchu_02.jpg | 曾 成訓 | CC BY 2.0 | 2026-11-15 |
| next_tsmc_fab_hsinchu_3.jpg | File:TSMC Fab 12A 02.jpg | https://commons.wikimedia.org/wiki/File:TSMC_Fab_12A_02.jpg | 曾 成訓 | CC BY 2.0 | 2026-11-15 |
| out_amd_hq.jpg | File:2485 Augustine Drive headquarters in Santa Clara, California.jpg | https://commons.wikimedia.org/wiki/File:2485_Augustine_Drive_headquarters_in_Santa_Clara,_California.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| out_bloomberg_731.jpg | File:731 Lexington Avenue (55272623112).jpg | https://commons.wikimedia.org/wiki/File:731_Lexington_Avenue_(55272623112).jpg | ajay_suresh | CC BY 4.0 | 2026-11-15 |
| out_bloomberg_tower.jpg | File:Bloomberg Tower 005.jpg | https://commons.wikimedia.org/wiki/File:Bloomberg_Tower_005.jpg | Kidfly182 | CC BY 4.0 | 2026-11-15 |
| out_broadcom_hq.jpg | File:Broadcom Headquarters San Jose.jpg | https://commons.wikimedia.org/wiki/File:Broadcom_Headquarters_San_Jose.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| out_endeavor_atrium_2017.jpg | File:Nvdia Endeavor Grand Opening atrium and cocoon Prostak Gensler.jpg | https://commons.wikimedia.org/wiki/File:Nvdia_Endeavor_Grand_Opening_atrium_and_cocoon_Prostak_Gensler.jpg | Daniel J. Prostak Crocodiletiger~commonswiki used courtesy of Jessie Shao | CC BY-SA 4.0 | 2026-11-15 |
| out_jh_2011_ces.jpg | File:엔비디아 옵티머스2X (5329363216).jpg | https://commons.wikimedia.org/wiki/File:%EC%97%94%EB%B9%84%EB%94%94%EC%95%84_%EC%98%B5%ED%8B%B0%EB%A8%B8%EC%8A%A42X_(5329363216).jpg | LG전자 | CC BY 2.0 | 2026-11-15 |
| out_jh_2014.jpg | File:Jen-Hsun Huang Headshot (15313247387).jpg | https://commons.wikimedia.org/wiki/File:Jen-Hsun_Huang_Headshot_(15313247387).jpg | nvidia.corporation | CC BY-SA 2.0 | 2026-11-15 |
| out_jh_2017_ces.jpg | File:Nvidia CEO Jensen Huang gestikuliert.jpg | https://commons.wikimedia.org/wiki/File:Nvidia_CEO_Jensen_Huang_gestikuliert.jpg | Maurizio Pesce | CC BY 2.0 | 2026-11-15 |
| out_jh_2018_sc18.jpg | File:JensenHuangSC18.jpg | https://commons.wikimedia.org/wiki/File:JensenHuangSC18.jpg | Raysonho @ Open Grid Scheduler / Scalable Grid Engine | CC0 | 2026-11-15 |
| out_jh_2025_ces.jpg | File:Jensen Huang - Nvidia Keynote - CES 2025 Las Vegas (1).jpg | https://commons.wikimedia.org/wiki/File:Jensen_Huang_-_Nvidia_Keynote_-_CES_2025_Las_Vegas_(1).jpg | Pronoia | CC0 | 2026-11-15 |
| out_nasdaq_marketsite.jpg | File:Nasdaq MarketSite (51494550508).jpg | https://commons.wikimedia.org/wiki/File:Nasdaq_MarketSite_(51494550508).jpg | ajay_suresh | CC BY 2.0 | 2026-11-15 |
| out_nasdaq_tower_2026.jpg | File:Nasdaq Tower May 2026.jpg | https://commons.wikimedia.org/wiki/File:Nasdaq_Tower_May_2026.jpg | Nielsoncaetanosalmeron | CC BY 4.0 | 2026-11-15 |
| out_newscorp_ticker.jpg | File:48th St 6th Av td 17 - 1211 Avenue of the Americas.jpg | https://commons.wikimedia.org/wiki/File:48th_St_6th_Av_td_17_-_1211_Avenue_of_the_Americas.jpg | Tdorante10 | CC BY-SA 4.0 | 2026-11-15 |
| out_newscorp_west.jpg | File:48th St 6th Av td 24 - 1211 Avenue of the Americas.jpg | https://commons.wikimedia.org/wiki/File:48th_St_6th_Av_td_24_-_1211_Avenue_of_the_Americas.jpg | Tdorante10 | CC BY-SA 4.0 | 2026-11-15 |
| out_nvhq_2005.jpg | File:Nvidia HQ.jpg | https://commons.wikimedia.org/wiki/File:Nvidia_HQ.jpg | Kevin McCarthy | CC BY 2.0 | 2026-11-15 |
| out_nvhq_2008.jpg | File:Nvidiaheadquarters.jpg | https://commons.wikimedia.org/wiki/File:Nvidiaheadquarters.jpg | Coolcaesar at English Wikipedia | CC BY-SA 3.0 | 2026-11-15 |
| out_nvhq_2018.jpg | File:NVIDIA Headquarters.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_Headquarters.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| out_nvhq_entrance_2022.jpg | File:2788-2888 San Tomas Expressway.jpg | https://commons.wikimedia.org/wiki/File:2788-2888_San_Tomas_Expressway.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| out_nyt_logo.jpg | File:New York Times Building - New York Times Logo (48193455772).jpg | https://commons.wikimedia.org/wiki/File:New_York_Times_Building_-_New_York_Times_Logo_(48193455772).jpg | Ajay Suresh from New York, NY, USA | CC BY 2.0 | 2026-11-15 |
| out_nyt_sunset.jpg | File:The New York Times Building at sunset, 2021-09-30.jpg | https://commons.wikimedia.org/wiki/File:The_New_York_Times_Building_at_sunset,_2021-09-30.jpg | Jdforrester | CC BY 4.0 | 2026-11-15 |
| out_nyt_tower.jpg | File:New York Times Tower (52182055042).jpg | https://commons.wikimedia.org/wiki/File:New_York_Times_Tower_(52182055042).jpg | Eden, Janine and Jim from New York City | CC BY 2.0 | 2026-11-15 |
| price_clay_county_kentucky_mountai_1.jpg | File:Big Hill 2016-09-27 267.jpg | https://commons.wikimedia.org/wiki/File:Big_Hill_2016-09-27_267.jpg | Chris Light | CC BY-SA 4.0 | 2026-11-15 |
| price_denny_s_berryessa_san_jose_1.jpg | File:2484 Berryessa Road.jpg | https://commons.wikimedia.org/wiki/File:2484_Berryessa_Road.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| price_denny_s_restaurant_californi_1.jpg | File:Denny's in California.jpg | https://commons.wikimedia.org/wiki/File:Denny%27s_in_California.jpg | Kiddo27 | CC BY-SA 4.0 | 2026-11-15 |
| price_denny_s_restaurant_californi_2.jpg | File:Denny's Ripon, California.jpg | https://commons.wikimedia.org/wiki/File:Denny%27s_Ripon,_California.jpg | TaurusEmerald | CC BY-SA 4.0 | 2026-11-15 |
| price_denny_s_restaurant_californi_3.jpg | File:Denny's in Pacific Beach, California (26172653162).jpg | https://commons.wikimedia.org/wiki/File:Denny%27s_in_Pacific_Beach,_California_(26172653162).jpg | chrisinphilly5448 from San Diego, United States | CC BY-SA 2.0 | 2026-11-15 |
| price_jen_hsun_huang_engineering_c_1.jpg | File:Jen-Hsun Huang Engineering Center in 2016.jpg | https://commons.wikimedia.org/wiki/File:Jen-Hsun_Huang_Engineering_Center_in_2016.jpg | Frank Schulenburg | CC BY-SA 4.0 | 2026-11-15 |
| price_jen_hsun_huang_engineering_c_2.jpg | File:Stanford University, Jen-Hsun Huang Engineering Center, May 28, 2023 - 73.jpg | https://commons.wikimedia.org/wiki/File:Stanford_University,_Jen-Hsun_Huang_Engineering_Center,_May_28,_2023_-_73.jpg | 94rain | CC BY-SA 4.0 | 2026-11-15 |
| price_jen_hsun_huang_engineering_c_3.jpg | File:Stanford Huang Nvidia.jpg | https://commons.wikimedia.org/wiki/File:Stanford_Huang_Nvidia.jpg | Cullen328 | CC BY-SA 3.0 | 2026-11-15 |
| price_lsi_logic_2.jpg | File:LSI Logic 01-01037-07-2352.jpg | https://commons.wikimedia.org/wiki/File:LSI_Logic_01-01037-07-2352.jpg | Raimond Spekking | CC BY-SA 4.0 | 2026-11-15 |
| price_lsi_logic_3.jpg | File:LSI Logic L64132 die.jpg | https://commons.wikimedia.org/wiki/File:LSI_Logic_L64132_die.jpg | Pauli Rautakorpi | CC BY 3.0 | 2026-11-15 |
| price_new_york_stock_exchange_trad_1.jpg | File:No Known Restrictions Trading Floor, New York Stock Exchange (Highsmith LOC) (6718386525).jpg | https://commons.wikimedia.org/wiki/File:No_Known_Restrictions_Trading_Floor,_New_York_Stock_Exchange_(Highsmith_LOC)_(6718386525).jpg | Carol M. Highsmith | Public domain | 2026-11-15 |
| price_new_york_stock_exchange_trad_3.jpg | File:New York Stock Exchange, Manhattan, New York (7236984682).jpg | https://commons.wikimedia.org/wiki/File:New_York_Stock_Exchange,_Manhattan,_New_York_(7236984682).jpg | Ken Lund from Reno, Nevada, USA | CC BY-SA 2.0 | 2026-11-15 |
| price_oneida_baptist_institute_1.jpg | File:Calf igloos at OBI, Kentucky, USA.jpg | https://commons.wikimedia.org/wiki/File:Calf_igloos_at_OBI,_Kentucky,_USA.jpg | James Thompson | CC BY 2.0 | 2026-11-15 |
| price_oneida_kentucky_1.jpg | File:River Street in Oneida.jpg | https://commons.wikimedia.org/wiki/File:River_Street_in_Oneida.jpg | Nyttend | Public domain | 2026-11-15 |
| price_oneida_kentucky_2.jpg | File:Oneida post office 40972.jpg | https://commons.wikimedia.org/wiki/File:Oneida_post_office_40972.jpg | Nyttend | Public domain | 2026-11-15 |
| price_oneida_kentucky_3.jpg | File:Oneida Community Church.jpg | https://commons.wikimedia.org/wiki/File:Oneida_Community_Church.jpg | Nyttend | Public domain | 2026-11-15 |
| price_oregon_state_university_kell_1.jpg | File:Kelley Engineering Center, Oregon State University, Corvallis - DPLA - 7d62bbb8efa766fe8182058af5c5f85a.jpg | https://commons.wikimedia.org/wiki/File:Kelley_Engineering_Center,_Oregon_State_University,_Corvallis_-_DPLA_-_7d62bbb8efa766fe8182058af5c5f85a.jpg | Gary Halvorson, Oregon State Archives | CC BY 4.0 | 2026-11-15 |
| price_stanford_graduate_school_of__1.jpg | File:Knight Management Center.jpg | https://commons.wikimedia.org/wiki/File:Knight_Management_Center.jpg | Steve Castillo | CC BY 3.0 | 2026-11-15 |
| price_stanford_graduate_school_of__2.jpg | File:Stanford University from Hoover Tower January 2013 002.jpg | https://commons.wikimedia.org/wiki/File:Stanford_University_from_Hoover_Tower_January_2013_002.jpg | King of Hearts | CC BY-SA 3.0 | 2026-11-15 |
| rev_apple_campus_infinite_loop_1.jpg | File:Apple Headquarters in Cupertino.jpg | https://commons.wikimedia.org/wiki/File:Apple_Headquarters_in_Cupertino.jpg | Joe Ravi (Shutterstock iStock Dreamstime) | CC BY-SA 3.0 | 2026-11-15 |
| rev_apple_campus_infinite_loop_2.jpg | File:Apple Campus One Infinite Loop Sign.jpg | https://commons.wikimedia.org/wiki/File:Apple_Campus_One_Infinite_Loop_Sign.jpg | Joe Ravi (Shutterstock iStock Dreamstime) | CC BY-SA 3.0 | 2026-11-15 |
| rev_apple_campus_infinite_loop_3.jpg | File:Apple Infinite Loop Aerial.jpg | https://commons.wikimedia.org/wiki/File:Apple_Infinite_Loop_Aerial.jpg | InvadingInvader | CC BY-SA 4.0 | 2026-11-15 |
| rev_apple_ii_computer_1.jpg | File:Apple II at Musée Bolo.jpg | https://commons.wikimedia.org/wiki/File:Apple_II_at_Mus%C3%A9e_Bolo.jpg | Rama &amp; Musée Bolo | CC BY-SA 2.0 fr | 2026-11-15 |
| rev_apple_ii_computer_2.jpg | File:Apple II IMG 4218-black.jpg | https://commons.wikimedia.org/wiki/File:Apple_II_IMG_4218-black.jpg | Rama &amp; Musée Bolo | CC BY-SA 2.0 fr | 2026-11-15 |
| rev_apple_lisa_computer_1.jpg | File:Apple Lisa Computer.jpg | https://commons.wikimedia.org/wiki/File:Apple_Lisa_Computer.jpg | Timothy Colegrove | CC BY-SA 4.0 | 2026-11-15 |
| rev_apple_park_aerial_1.jpg | File:Apple park cupertino 2019.jpg | https://commons.wikimedia.org/wiki/File:Apple_park_cupertino_2019.jpg | Arne Müseler | CC BY-SA 3.0 de | 2026-11-15 |
| rev_apple_park_aerial_2.jpg | File:Apple Park 2022.jpg | https://commons.wikimedia.org/wiki/File:Apple_Park_2022.jpg | InvadingInvader | CC BY-SA 4.0 | 2026-11-15 |
| rev_google_tpu_1.png | File:TPU v4.png | https://commons.wikimedia.org/wiki/File:TPU_v4.png | Norman P. Jouppi, George Kurian, Sheng Li, Peter Ma, Rahul Nagarajan, Lifeng Nai | CC BY 4.0 | 2026-11-15 |
| rev_google_tpu_2.jpg | File:Tensor Processing Unit 3.0.jpg | https://commons.wikimedia.org/wiki/File:Tensor_Processing_Unit_3.0.jpg | Zinskauf | CC BY-SA 4.0 | 2026-11-15 |
| rev_iphone_4s_1.jpg | File:IPhone 4s Rear Side.jpg | https://commons.wikimedia.org/wiki/File:IPhone_4s_Rear_Side.jpg | IGeeksBlog | CC BY-SA 4.0 | 2026-11-15 |
| rev_iphone_4s_2.jpg | File:IPhone 4s Close-up.jpg | https://commons.wikimedia.org/wiki/File:IPhone_4s_Close-up.jpg | IGeeksBlog | CC BY-SA 4.0 | 2026-11-15 |
| rev_macintosh_128k_1.jpg | File:Steve Jobs and Macintosh computer, January 1984, by Bernard Gotfryd - edited.jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_and_Macintosh_computer,_January_1984,_by_Bernard_Gotfryd_-_edited.jpg | Photo: Bernard Gotfryd - Edited from tif by Cart | Public domain | 2026-11-15 |
| rev_macintosh_128k_2.jpg | File:Computer macintosh 128k, 1984 (all about Apple onlus).jpg | https://commons.wikimedia.org/wiki/File:Computer_macintosh_128k,_1984_(all_about_Apple_onlus).jpg | Sailko | CC BY 3.0 | 2026-11-15 |
| rev_next_computer_cube_1.jpg | File:NEXT Cube-IMG 7154.jpg | https://commons.wikimedia.org/wiki/File:NEXT_Cube-IMG_7154.jpg | Rama &amp; Musée Bolo | CC BY-SA 2.0 fr | 2026-11-15 |
| rev_next_computer_cube_2.jpg | File:Living Computers - NeXT Cube (39802959523).jpg | https://commons.wikimedia.org/wiki/File:Living_Computers_-_NeXT_Cube_(39802959523).jpg | Michael Dunn from Silicon Valley, USA | CC BY 2.0 | 2026-11-15 |
| rev_steve_jobs_1984_1.jpg | File:Steve Jobs January 1984.jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_January_1984.jpg | Photo: Bernard Gotfryd - Edited from tif by Cart | Public domain | 2026-11-15 |
| rev_steve_jobs_2007_iphone_1.jpg | File:Steve Jobs presents iPhone (cropped 3-2).jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_presents_iPhone_(cropped_3-2).jpg | Blake Patterson | CC BY 2.0 | 2026-11-15 |
| rev_steve_jobs_2007_iphone_2.jpg | File:Steve Jobs presents iPhone.jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_presents_iPhone.jpg | Blake Patterson | CC BY 2.0 | 2026-11-15 |
| rev_steve_jobs_john_sculley_1.jpg | File:Steve Jobs Headshot 2010-CROP.jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_Headshot_2010-CROP.jpg | Matthew Yohe (talk) | CC BY-SA 3.0 | 2026-11-15 |
| rev_steve_jobs_john_sculley_3.jpg | File:Steve Jobs 2007.jpg | https://commons.wikimedia.org/wiki/File:Steve_Jobs_2007.jpg | Ben Stanfield | CC BY-SA 2.0 | 2026-11-15 |
| why_brian_krzanich_intel_1.jpg | File:Brian Krzanich, Intel Chief Executive Officer.jpg | https://commons.wikimedia.org/wiki/File:Brian_Krzanich,_Intel_Chief_Executive_Officer.jpg | AP Photo/Intel Corporation,Bob Riha, Jr. | CC BY-SA 2.0 | 2026-11-15 |
| why_intel_headquarters_robert_no_1.jpg | File:Intel Headquarters in 2023.jpg | https://commons.wikimedia.org/wiki/File:Intel_Headquarters_in_2023.jpg | Coolcaesar | CC BY-SA 4.0 | 2026-11-15 |
| why_intel_wafer_1.jpg | File:4th Generation Intel® Core™ Processor Wafer Black.jpg | https://commons.wikimedia.org/wiki/File:4th_Generation_Intel%C2%AE_Core%E2%84%A2_Processor_Wafer_Black.jpg | Intel in Deutschland | CC BY-SA 2.0 | 2026-11-15 |
| why_intel_wafer_2.jpg | File:4th Generation Intel® Core™ Processor Wafer White.jpg | https://commons.wikimedia.org/wiki/File:4th_Generation_Intel%C2%AE_Core%E2%84%A2_Processor_Wafer_White.jpg | Intel in Deutschland | CC BY-SA 2.0 | 2026-11-15 |
| why_intel_wafer_3.jpg | File:Wafer at Intel Museum.JPG | https://commons.wikimedia.org/wiki/File:Wafer_at_Intel_Museum.JPG | Oleg Alexandrov | CC BY-SA 3.0 | 2026-11-15 |
| why_mark_zuckerberg_2024_1.jpg | File:Mark Zuckerberg 2019 (cropped).jpg | https://commons.wikimedia.org/wiki/File:Mark_Zuckerberg_2019_(cropped).jpg | Anthony Quintano from Westminster, United States | CC BY 2.0 | 2026-11-15 |
| why_mark_zuckerberg_f8_1.jpg | File:Mark Zuckerberg F8 2018 Keynote (cropped).jpg | https://commons.wikimedia.org/wiki/File:Mark_Zuckerberg_F8_2018_Keynote_(cropped).jpg | Anthony Quintano from Honolulu, HI, United States | CC BY 2.0 | 2026-11-15 |
| why_mark_zuckerberg_f8_2.jpg | File:Mark Zuckerberg F8 2018 Keynote.jpg | https://commons.wikimedia.org/wiki/File:Mark_Zuckerberg_F8_2018_Keynote.jpg | Anthony Quintano from Honolulu, HI, United States | CC BY 2.0 | 2026-11-15 |
| why_mark_zuckerberg_f8_3.jpg | File:Mark Zuckerberg F8 2019 Keynote (32830578717).jpg | https://commons.wikimedia.org/wiki/File:Mark_Zuckerberg_F8_2019_Keynote_(32830578717).jpg | Anthony Quintano from Westminster, United States | CC BY 2.0 | 2026-11-15 |
| why_meta_headquarters_menlo_park_1.jpg | File:Meta Platforms Headquarters Menlo Park California.jpg | https://commons.wikimedia.org/wiki/File:Meta_Platforms_Headquarters_Menlo_Park_California.jpg | LPS.1 | CC0 | 2026-11-15 |
| why_meta_headquarters_menlo_park_2.jpg | File:Aerial view of Facebook campus in Menlo Park, September 2019.JPG | https://commons.wikimedia.org/wiki/File:Aerial_view_of_Facebook_campus_in_Menlo_Park,_September_2019.JPG | Pi.1415926535 | CC BY-SA 3.0 | 2026-11-15 |
| why_meta_headquarters_menlo_park_3.png | File:Meta HQ 2023.png | https://commons.wikimedia.org/wiki/File:Meta_HQ_2023.png | InvadingInvader | CC BY-SA 4.0 | 2026-11-15 |
| why_pat_gelsinger_intel_1.jpg | File:Pat Gelsinger.jpg | https://commons.wikimedia.org/wiki/File:Pat_Gelsinger.jpg | [Web Summit https://www.flickr.com/people/74711243@N06] | CC BY 2.5 | 2026-11-15 |
| why_pat_gelsinger_intel_2.jpg | File:Web Summit 2017 - SaaS Monster CG1 8444 (26490847329) (cropped).jpg | https://commons.wikimedia.org/wiki/File:Web_Summit_2017_-_SaaS_Monster_CG1_8444_(26490847329)_(cropped).jpg | Web Summit | CC BY 2.0 | 2026-11-15 |
| why_united_states_capitol_dome_n_2.jpg | File:The dome of the United States Capitol building.jpg | https://commons.wikimedia.org/wiki/File:The_dome_of_the_United_States_Capitol_building.jpg | peakfocus.agency | CC BY 4.0 | 2026-11-15 |
| why_united_states_capitol_dome_n_3.jpg | File:United States Capitol dome at night.jpg | https://commons.wikimedia.org/wiki/File:United_States_Capitol_dome_at_night.jpg | APK | CC BY-SA 4.0 | 2026-11-15 |

### 英伟达新闻室的照片（assets/photos/nv_newsroom/）

来源页：https://nvidianews.nvidia.com/multimedia/santa-clara-headquarters（总部照片）和 https://nvidianews.nvidia.com/bios/jensen-huang（官方肖像）。页面没有单独的使用条件，适用全站条款；几张总部照片署名 Gensler | Jason O'Rear Photography。只下到 700 像素的预览版，原图链接返回的是网页，没有硬取。下载日期 2026-11-15。

文件：DH1L4415_HDR_20220527_r5.jpg、DH1L4494_HDR_20220531_r4.jpg、NVIDIA_Endeavor_building_logo.jpg、NVIDIA_Voyager_and_park.jpg、NVIDIA_aerial_Voyager_and_Endeavor.jpg、NVIDIA_park_and_walkway.jpg、NVIDIA_park_and_walkway_2.jpg、NVIDIA_voyager_interior.jpg、Voyager_interior_1.jpg、Voyager_interior_2.jpg、Voyager_interior_3.jpg、Voyager_interior_4.jpg、Voyager_mezzanine.jpg、jensen_bio_headshot.jpg、voyager_exterior_sign_2.jpg

### 新截的网页（assets/docs/v8/）

| 文件 | 内容 | 网址 | 版权 | 授权 | 截图日期 |
|---|---|---|---|---|---|
| nv_bio_page.png | 英伟达官网黄仁勋简介页整页截图 | https://nvidianews.nvidia.com/bios/jensen-huang | NVIDIA | 网页截图，评论引用 | 2026-11-15 |
| nv_hq_gallery.png | 英伟达新闻室总部照片页截图 | https://nvidianews.nvidia.com/multimedia/santa-clara-headquarters | NVIDIA | 网页截图，评论引用 | 2026-11-15 |
| poly_mirror_market.png | 预测市场页面截图（接班人那一条） | https://cryptoslate.com/predictions/market/jensen-huang-announced-resignation-or-removal-by-december-31/ | 见网址 | 网页截图，评论引用 | 2026-11-15 |

### 只拿来分析、不进成片的

- 主讲给的样板视频（B 站，「没有老黄的英伟达，会黄吗？」，主讲本机文件）：只在本机转成文字、数镜头，学文案和节奏，不用它的画面、声音和句子。
- 小Lin说三期节目的字幕文字（YouTube：2MJt1dTqbPk、EdTPykGAe0Q、OcKl98ZQbMQ）：只用来量问句密度、因果句比例这些，不引用。
- 约 190 个候选视频的缩略图条（work_v9/assets_v2/sb/）：只用来挑时间段，不进成片。

## v17 补的素材（2026-11-16 凌晨；稿子换成 v17 以后给新镜头表补的）

下载都由总管主进程做，请求头只写项目名；遇到拦截就停，不绕。

### 采访原话的片段（YouTube，带原声；版权归原频道，评论引用）

| 文件（assets/src_clips/v2_gap/） | 取的时间段（秒） | 视频 | 网址 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| lex_succession.mp4 | 8302–8322 | Lex Fridman Podcast #494 · Jensen Huang（2026.3） | https://www.youtube.com/watch?v=vif8NQcjVf0 | 版权所有，评论引用片段 | 2026-11-16 |
| lex_sixty.mp4 | 339–357 | Lex Fridman Podcast #494 · Jensen Huang（2026.3） | https://www.youtube.com/watch?v=vif8NQcjVf0 | 版权所有，评论引用片段 | 2026-11-16 |
| stripe_incompetent_clip.mp4 | 1568–1593 | Stripe Sessions 2024 · A conversation with NVIDIA’s Jensen Huang | https://www.youtube.com/watch?v=8Pfa8kPjUio | 版权所有，评论引用片段 | 2026-11-16 |
| rogan_dgx_clip.mp4 | 4534–4566 | Joe Rogan Experience #2422 · Jensen Huang（2025.12） | https://www.youtube.com/watch?v=3hptKYix4X8 | 版权所有，评论引用片段 | 2026-11-16 |

这三期的英文自动字幕（work_v9/assets_v2/v17/subs/）只用来找时间码，不进成片。

### 实拍（Pexels，Pexels License：免费使用，不要求署名）

| 文件（assets/src_clips/v2_gap/） | 作品页 | 用法 | 下载日期 |
|---|---|---|---|
| pexels_7607448_allin_man_bets.mp4 | https://www.pexels.com/video/man-bets-all-in-the-gambling-chips-7607448/ | 牌桌：裁成 poker_push.mp4、poker_after.mp4（裁掉了人脸） | 2026-11-16 |
| pexels_6962282_allin_put_chips.mp4 | https://www.pexels.com/video/a-man-put-poker-chips-all-in-6962282/ | 候选，没用 | 2026-11-16 |
| pexels_7607942_stacking_chips.mp4 | https://www.pexels.com/video/a-gambler-stacking-poker-chips-7607942/ | 牌桌：poker_hand.mp4 | 2026-11-16 |
| pexels_40548601_empty_poker_table.mp4 | https://www.pexels.com/video/empty-poker-table-with-playing-cards-40548601/ | 牌桌：poker_empty_table.mp4 | 2026-11-16 |
| pexels_35429456_chips_cards_table.mp4 | https://www.pexels.com/video/colorful-chips-and-playing-cards-on-a-casino-table-35429456/ | 候选，没用 | 2026-11-16 |
| pexels_6206031_tossing_chips.mp4 | https://www.pexels.com/video/close-up-view-of-playing-cards-and-tossing-casino-chips-6206031/ | 候选，没用 | 2026-11-16 |
| pexels_35728850_table_action_closeup.mp4 | https://www.pexels.com/video/casino-table-poker-game-action-close-up-35728850/ | 候选，没用 | 2026-11-16 |
| pexels_7683460_cards_chips.mp4 | https://www.pexels.com/video/game-cards-and-poker-chips-7683460/ | 候选，没用 | 2026-11-16 |
| pexels_27047889_fishing_silhouette.mp4 | https://www.pexels.com/video/silhouette-of-a-man-fishing-at-sunset-27047889/ | fishing.mp4 | 2026-11-16 |
| pexels_856829_fishing_rod_closeup.mp4 | https://www.pexels.com/video/close-up-video-of-fishing-rod-856829/ | 候选，没用 | 2026-11-16 |
| pexels_32159405_fishing_reel_pier.mp4 | https://www.pexels.com/video/close-up-of-fishing-reel-on-a-pier-outdoors-32159405/ | 候选，没用 | 2026-11-16 |
| pexels_25916190_fishing_rod_sunset.mp4 | https://www.pexels.com/video/a-person-holding-a-fishing-rod-at-sunset-25916190/ | 候选，没用 | 2026-11-16 |
| pexels_8471105_sign_document_closeup.mp4 | https://www.pexels.com/video/close-up-video-of-a-person-signing-a-document-8471105/ | lease_sign_2.mp4 | 2026-11-16 |
| pexels_10375432_handing_keys.mp4 | https://www.pexels.com/video/handing-over-the-keys-10375432/ | lease_sign.mp4 | 2026-11-16 |
| pexels_7577972_key_and_paper.mp4 | https://www.pexels.com/video/person-holding-a-key-and-paper-7577972/ | 候选，没用 | 2026-11-16 |
| pexels_7646698_sign_contract_closeup.mp4 | https://www.pexels.com/video/close-up-view-of-a-person-signing-a-contract-7646698/ | 候选，没用 | 2026-11-16 |

### 维基共享资源的照片（assets/photos/v2_gap/）

| 文件 | 原题 | 页面 | 作者 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| altman_photo.jpg | File:Sam Altman November 2022.jpg | https://commons.wikimedia.org/wiki/File:Sam_Altman_November_2022.jpg | Village Global | CC BY 2.0 | 2026-11-16 |
| blackrock_hq.jpg | File:50 Hudson Yards 003.jpg | https://commons.wikimedia.org/wiki/File:50_Hudson_Yards_003.jpg | Kidfly182 | CC BY 4.0 | 2026-11-16 |
| blackrock_hq_2.jpg | File:50 Hudson Yards 002.jpg | https://commons.wikimedia.org/wiki/File:50_Hudson_Yards_002.jpg | Kidfly182 | CC BY 4.0 | 2026-11-16 |
| dc_card_h100.png | File:NVIDIA H100 (极客湾Geekerwan) 024.png | https://commons.wikimedia.org/wiki/File:NVIDIA_H100_(%E6%9E%81%E5%AE%A2%E6%B9%BEGeekerwan)_024.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-16 |
| dc_card_h100_2.png | File:NVIDIA H100 (极客湾Geekerwan) 002.png | https://commons.wikimedia.org/wiki/File:NVIDIA_H100_(%E6%9E%81%E5%AE%A2%E6%B9%BEGeekerwan)_002.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-16 |
| doj_building.jpg | File:Robert F. Kennedy Department of Justice Building.jpg | https://commons.wikimedia.org/wiki/File:Robert_F._Kennedy_Department_of_Justice_Building.jpg | APK | CC BY 4.0 | 2026-11-16 |
| haas_photo.jpg | File:Rene Haas at Web Summit 2022.jpg | https://commons.wikimedia.org/wiki/File:Rene_Haas_at_Web_Summit_2022.jpg | Web Summit | CC BY 2.0 | 2026-11-16 |
| icera_tegra.jpg | File:NVIDIA T20 and T30 chips.jpg | https://commons.wikimedia.org/wiki/File:NVIDIA_T20_and_T30_chips.jpg | Poeggi | CC BY-SA 3.0 | 2026-11-16 |
| kress_photo.png | File:Colette Kress (1).png | https://commons.wikimedia.org/wiki/File:Colette_Kress_(1).png | SiliconANGLE theCUBE | CC BY 4.0 | 2026-11-16 |
| mac_m4_review.png | File:Review zu Apple Hardware mit Apple M4-CPUs (Geekerwan) 01.png | https://commons.wikimedia.org/wiki/File:Review_zu_Apple_Hardware_mit_Apple_M4-CPUs_(Geekerwan)_01.png | 极客湾Geekerwan | CC BY 3.0 | 2026-11-16 |
| milk_tea.jpg | File:A bubble tea with tapioca pearls, July 2018.jpg | https://commons.wikimedia.org/wiki/File:A_bubble_tea_with_tapioca_pearls,_July_2018.jpg | sam651030 from Pixabay | CC0 | 2026-11-16 |
| mining_rig.jpg | File:Mining-Rig.jpg | https://commons.wikimedia.org/wiki/File:Mining-Rig.jpg | Jasper Reichardt | CC BY-SA 4.0 | 2026-11-16 |
| mlnx_hca.jpg | File:Supermicro AOC-UIBQ-M2 dual port InfiniBand HCA.jpg | https://commons.wikimedia.org/wiki/File:Supermicro_AOC-UIBQ-M2_dual_port_InfiniBand_HCA.jpg | Dmitry Nosachev | CC BY-SA 4.0 | 2026-11-16 |
| mlnx_photo.jpg | File:MELLANOX - 1024.jpg | https://commons.wikimedia.org/wiki/File:MELLANOX_-_1024.jpg | Cecetay | CC BY-SA 4.0 | 2026-11-16 |
| mlnx_photo_2.jpg | File:Nvidia Yokneam Office.jpg | https://commons.wikimedia.org/wiki/File:Nvidia_Yokneam_Office.jpg | Amir Shtanger (אמיר שטנגר) | CC BY-SA 4.0 | 2026-11-16 |
| printing_press.jpg | File:Offset printing press 2.jpg | https://commons.wikimedia.org/wiki/File:Offset_printing_press_2.jpg | Aatu Dorochenko | CC BY-SA 4.0 | 2026-11-16 |
| printing_press_2.jpg | File:Web-fed offset press printing newspapers.jpg | https://commons.wikimedia.org/wiki/File:Web-fed_offset_press_printing_newspapers.jpg | Tom T | CC BY 2.0 | 2026-11-16 |
| senate_dirksen.jpg | File:Dirksen Senate Office Building (53831703501).jpg | https://commons.wikimedia.org/wiki/File:Dirksen_Senate_Office_Building_(53831703501).jpg | ajay_suresh | CC BY 2.0 | 2026-11-16 |
| tegra2_board.jpg | File:Motorola Xoom - nvidia Tegra 2 T20-H-A2 on main board-0121.jpg | https://commons.wikimedia.org/wiki/File:Motorola_Xoom_-_nvidia_Tegra_2_T20-H-A2_on_main_board-0121.jpg | Raimond Spekking | CC BY-SA 4.0 | 2026-11-16 |

### 新截的网页（assets/docs/v8/；一页只访问一次）

| 文件 | 页面标题 | 网址 | 授权 | 截图日期 |
|---|---|---|---|---|
| mlnx_page.png | NVIDIA to Acquire Mellanox for $6.9 Billion ｜ NVIDIA Newsroom | https://nvidianews.nvidia.com/news/nvidia-to-acquire-mellanox-for-6-9-billion | 网页截图，评论引用 | 2026-11-16 |
| investigators_page.png | Statement From the Independent Members of the NVIDIA Board ｜ NVIDIA Newsroom | https://nvidianews.nvidia.com/news/statement-from-the-independent-members-of-the-nvidia-board | 网页截图，评论引用 | 2026-11-16 |
| kress_bio.png | Colette Kress ｜ NVIDIA Newsroom | https://nvidianews.nvidia.com/bios/colette-kress | 网页截图，评论引用 | 2026-11-16 |
| arm_termination.png | NVIDIA and SoftBank Group Announce Termination of NVIDIA’s Acquisition of Arm Limited ｜ NV | https://nvidianews.nvidia.com/news/nvidia-and-softbank-group-announce-termination-of-nvidias-acquisition-of-arm-limited | 网页截图，评论引用 | 2026-11-16 |
| icera_winddown.png | NVIDIA to Wind Down Icera Modem Operations ｜ NVIDIA Newsroom | https://nvidianews.nvidia.com/news/nvidia-to-wind-down-icera-modem-operations | 网页截图，评论引用 | 2026-11-16 |
| dc_q2_page.png | NVIDIA Announces Financial Results for Second Quarter Fiscal 2027 ｜ NVIDIA Newsroom | https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-second-quarter-fiscal-2027 | 网页截图，评论引用 | 2026-11-16 |
| t5t_page.png | Jensen Huang swears by email, not messaging apps, to manage Nvidia ｜ Fortune | https://fortune.com/2024/12/13/jensen-huang-email-nvidia-management-leadership-top-5-things-t5t/ | 网页截图，评论引用 | 2026-11-16 |
| crash_2008_page.png | Miss by chipmaker Nvidia rattles investors ｜ Fortune | https://fortune.com/2008/07/03/miss-by-chipmaker-nvidia-rattles-investors/ | 网页截图，评论引用 | 2026-11-16 |
| crash_2008_downgrades.png | Strong Analyst Defense of NVIDIA Against The Analyst Pack (NVDA) - 24/7 Wall St. | https://247wallst.com/investing/2008/07/03/strong-analyst/ | 网页截图，评论引用 | 2026-11-16 |
| musk_email_page.png | DGX-1 : le mail de 2016 qui nuance Jensen Huang | https://pausehardware.com/dgx-1-mail-2016-openai-jensen/ | 网页截图，评论引用 | 2026-11-16 |
| jul27_page.png | Nvidia announced $750bn of AI deals. Its own credit market flinched. | https://thenextweb.com/news/nvidia-announced-750bn-of-ai-deals-its-own-credit-market-flinched | 网页截图，评论引用 | 2026-11-16 |
| fox_wired_relay.png | Following Nvidia CEO Jensen Huang's resignation, some staff call to bring him back, report | https://foxnews.com/live-news/ai-news-china-nvidia-jensen-huang-resigns-super-intelligence-safety-11-13-26 | 网页截图，评论引用 | 2026-11-16 |
| cnbc_2023_openai.png | Hundreds of OpenAI employees threaten to follow Altman to Microsoft unless board resigns | https://www.cnbc.com/2023/11/20/hundreds-of-openai-employees-threaten-to-follow-altman-to-microsoft-unless-board-resigns-reports-say.html | 网页截图，评论引用 | 2026-11-16 |
| nyt_2023_openai_letter.png | The Employee Letter to OpenAI’s Board - The New York Times | https://www.nytimes.com/interactive/2023/11/20/technology/letter-to-the-open-ai-board.html | 网页截图，评论引用 | 2026-11-16 |
| blind_poll.png | 60% of Professionals Say Jensen Huang Should Remain Nvidia CEO Amid Affair Scandal, Blind  | https://www.teamblind.com/news/jensen-huang-should-remain-nvidia-ceo | 网页截图，评论引用 | 2026-11-16 |
| trump_post_relay.png | Trump floats Apple chairman Tim Cook as Jensen Huang's successor ｜ TechCrunch | https://techcrunch.com/2026/11/12/trump-floats-apple-chairman-tim-cook-as-jensen-huangs-successor/ | 网页截图，评论引用 | 2026-11-16 |
| ft_haas_page.png | Subscribe to read | https://www.ft.com/content/2a64f698-46dd-4178-a3f4-4c5f4c0a0926 | 网页截图，评论引用 | 2026-11-16 |
| cnbc_search_firm.png | Nvidia CEO: Search firm not yet selected for Huang replacement | https://www.cnbc.com/2026/11/13/nvidia-huang-ceo-replacement-search.html | 网页截图，评论引用 | 2026-11-16 |
| senate_relay.png | Senior Republican on US Senate banking panel calls on Nvidia CEO Huang to resign By Reuter | https://www.investing.com/news/stock-market-news/senior-republican-on-us-senate-banking-panel-calls-on-nvidia-ceo-huang-to-resign-5017609 | 网页截图，评论引用 | 2026-11-16 |
| axios_succession.png | Jensen Huang scandal: Nvidia has no obvious successor | https://www.axios.com/2026/11/09/nvidia-jensen-huang-succession-plan | 网页截图，评论引用 | 2026-11-16 |
| rtx5090d_cn_price.png | GeForce RTX 5090 D v2 显卡 ｜ NVIDIA | https://www.nvidia.cn/geforce/graphics-cards/50-series/rtx-5090-d/ | 网页截图，评论引用 | 2026-11-16 |

没截成（超时或被拦，没有重试）：wired_internal_post、ft_haas_relay。截到但是白页、不能用：fox_wired_relay、nyt_2023_openai_letter。

补（同上，维基共享资源，assets/photos/v2_gap/）：

| 文件 | 原题 | 页面 | 作者 | 授权 | 下载日期 |
|---|---|---|---|---|---|
| rtx5090_card.png | File:Palit GeForce RTX 5090 Gamerock 20250530 HOF3926-HDR RAW-Export.png | https://commons.wikimedia.org/wiki/File:Palit_GeForce_RTX_5090_Gamerock_20250530_HOF3926-HDR_RAW-Export.png | PantheraLeo1359531 | CC BY 4.0 | 2026-11-16 |

## v17 第二批补的素材（2026-11-16 凌晨，对照样板视频以后补的）

### 电视新闻、老采访、游戏实机（YouTube，只取窗口，只有画面；版权归原台和原频道，评论引用）

| 文件（assets/src_clips/v2_gap/） | 取的时间段（秒） | 视频 | 频道 | 网址 | 授权 | 下载日期 |
|---|---|---|---|---|---|---|
| tv_bbg_oust.mp4 | 0–30 | Nvidia Preparing to Oust CEO Jensen Huang: WSJ | Bloomberg Television | https://www.youtube.com/watch?v=h7Xq6wvIDWE | 版权所有，评论引用片段 | 2026-11-16 |
| tv_nbc_out.mp4 | 0–24 | Jensen Huang out as NVIDIA CEO | NBC News | https://www.youtube.com/watch?v=m7fEeojxZnU | 版权所有，评论引用片段 | 2026-11-16 |
| tv_nbc_cook.mp4 | 106–123 | Jensen Huang out as NVIDIA CEO | NBC News | https://www.youtube.com/watch?v=m7fEeojxZnU | 版权所有，评论引用片段 | 2026-11-16 |
| tv_today_kress.mp4 | 68–90 | Jensen Huang Resigns, Colette Kress Named Interim Nvidia CEO | TODAY（NBC） | https://www.youtube.com/watch?v=LDNV0WXrEA0 | 版权所有，评论引用片段 | 2026-11-16 |
| irimajiri_2000.mp4 | 534–604 | CBBC Newsround Extra - PS2 launch, Sega Dreamcast Shoichiro Irimajiri interview（2000 年 BBC 节目，个人上传的存档） | ajmetz82 | https://www.youtube.com/watch?v=2DAg2m0-o4c | 版权所有，评论引用片段 | 2026-11-16 |
| vf_gameplay.mp4 | 40–70 | Virtua Fighter (SEGA MODEL-1, 1993)（游戏版权归世嘉，实机录像） | Retrogamers Galaxy | https://www.youtube.com/watch?v=9ADukUbyPA8 | 版权所有，评论引用片段 | 2026-11-16 |

说明：NBC 那条原片 24 秒以后出现报道里两位私人的照片和名字，没有下，也不用。另外取了 8 个视频的缩略图总览（work_v9/assets_v2/sb/）用来挑时间段，不进成片。

### 补截的网页（assets/docs/v8/）

| 文件 | 内容 | 网址 | 授权 | 截图日期 |
|---|---|---|---|---|
| nv_proxy_2026_funds.png | 英伟达 2026 年委托书持股表里贝莱德那一行（7.43%） | https://web.archive.org/web/20261111131320id_/https://www.sec.gov/Archives/edgar/data/1045810/000104581026000036/nvda-20260512.htm | 公开文件，网页截图 | 2026-11-16 |
| nv_proxy_2026_vanguard.png | 同一张表里先锋那一行（7.31%） | 同上 | 公开文件，网页截图 | 2026-11-16 |

### 只拿来分析、不进成片的（补）

- 样板视频的声音：在本机拆成人声和伴奏（work/v11/ref/music/），只用来量配乐的铺法；截给主讲听的三小段（ref/music/send/）只在本机和主讲之间用。

## 质检以后补的素材（2026-11-16，总管下载）

| 文件 | 原标题 / 是什么 | 网址 | 作者 | 许可 | 取用日 |
|---|---|---|---|---|---|
| assets/photos/v2_gap/senate_hearing_room_2.jpg（senate_hearing_room.jpg 是同一张的小图，不用） | Hearing Room in the Hart Building（2017-01-06） | https://commons.wikimedia.org/wiki/File:Hearing_Room_in_the_Hart_Building.jpg | Architect of the Capitol | 公有领域（美国联邦政府作品） | 2026-11-16 |
| assets/src_clips/v2_gap/pexels_14513394_phone_scroll.mp4 | Hand Scrolling Cellphone Screen | https://www.pexels.com/video/hand-scrolling-cellphone-screen-14513394/ | Pexels 上传者（见页面） | Pexels License | 2026-11-16 |
| assets/src_clips/v2_gap/pexels_4426025_typing_kbd.mp4 | Close Up Shot of a Person Typing on a Computer Keyboard | https://www.pexels.com/video/close-up-shot-of-a-person-typing-on-a-computer-keyboard-4426025/ | Pexels 上传者（见页面） | Pexels License | 2026-11-16 |
| assets/src_clips/v2_gap/pexels_853774_typing_fingers.mp4（备用） | Close Up Video of Fingers Typing | https://www.pexels.com/video/close-up-video-of-fingers-typing-853774/ | Pexels 上传者（见页面） | Pexels License | 2026-11-16 |
| assets/src_clips/v2_gap/pexels_853935_laptop_open.mp4（备用） | Opening Laptop | https://www.pexels.com/video/opening-laptop-853935/ | Pexels 上传者（见页面） | Pexels License | 2026-11-16 |
| assets/src_clips/v2_gap/pexels_35888104_phone_feed.mp4（下了但不用：屏幕上有别人的脸和商标） | Scrolling Smartphone News Feed in Close Up | https://www.pexels.com/video/scrolling-smartphone-news-feed-in-close-up-35888104/ | Pexels 上传者（见页面） | Pexels License | 2026-11-16 |

说明：`v2_rest/next_him1_16.mp4`（片源表里登记在台积电 2025 年的片子名下）画面是那条片子引用的纽约时报 DealBook 峰会镜头，屏上只写「纽约时报 DealBook 峰会」，不写年份。
